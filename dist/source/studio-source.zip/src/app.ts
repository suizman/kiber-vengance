import { field, bindRuntime } from "./state/bindings";
import { projectTrackIds, trackMeta, trackKind } from "./state/tracks";
import { formatDb, levelDb } from "./ui/level-control";
import { setupOutputMix } from "./ui/output-mix";
import { voiceGenerationUnavailable } from "./ai/voice-safety";
import { bindNoteDrag as bindNoteGesture } from "./features/note-editor";
import { ProjectSession } from "./state/project-session";
import { ProjectRepository } from "./state/project-repository";
import { captureMusicalContext } from "./ai/composer";
import { requestConfirmation } from "./ui/dialogs";
import { recordPageError, type PageErrorInput } from "./ui/page-errors";
import {
  buildPresetClip,
  commitPresetClip,
  validateSoundPreset,
} from "./ai/presets";
import * as workflow from "./features/workflow";
import * as storage from "./features/storage";
import * as performanceFeature from "./features/performance";
import * as instruments from "./features/instruments";
import * as audio_studio from "./features/audio-studio";
import * as launcher from "./features/launcher";
import * as arrangement from "./features/arrangement";
import * as mixer from "./features/mixer";
import * as scratch from "./features/scratch";
import * as sampler from "./features/sampler";
// Application-owned state and services. Features receive typed subsets from state/contracts.ts.
// UI components never own the audio engine lifetime.
const runtime = bindRuntime({
  projectRepository: field(() => projectRepository),
  beginProjectEdit: field(() => beginProjectEdit),
  reportError: field(() => reportError),
  $: field(() => $),
  $$: field(() => $$),
  STORAGE: field(() => STORAGE),
  LEGACY_V5: field(() => LEGACY_V5),
  LEGACY_V4: field(() => LEGACY_V4),
  LEGACY_V3: field(() => LEGACY_V3),
  LEGACY: field(() => LEGACY),
  VERSIONS: field(() => VERSIONS),
  UI_STORAGE: field(() => UI_STORAGE),
  LANGUAGE_STORAGE: field(() => LANGUAGE_STORAGE),
  project: field(
    (): Project => project,
    (value) => {
      project = value;
    },
  ),
  selectedTrack: field(
    () => selectedTrack,
    (value) => {
      selectedTrack = value;
    },
  ),
  selectedNotes: field(
    () => selectedNotes,
    (value) => {
      selectedNotes = value;
    },
  ),
  currentStep: field(
    () => currentStep,
    (value) => {
      currentStep = value;
    },
  ),
  currentScene: field(
    () => currentScene,
    (value) => {
      currentScene = value;
    },
  ),
  transportPosition: field(
    () => transportPosition,
    (value) => {
      transportPosition = value;
    },
  ),
  globalStartStep: field(
    () => globalStartStep,
    (value) => {
      globalStartStep = value;
    },
  ),
  draggedScene: field(
    () => draggedScene,
    (value) => {
      draggedScene = value;
    },
  ),
  recordArmed: field(
    () => recordArmed,
    (value) => {
      recordArmed = value;
    },
  ),
  metronome: field(
    () => metronome,
    (value) => {
      metronome = value;
    },
  ),
  animation: field(
    () => animation,
    (value) => {
      animation = value;
    },
  ),
  clipboard: field(
    () => clipboard,
    (value) => {
      clipboard = value;
    },
  ),
  recording: field(
    () => recording,
    (value) => {
      recording = value;
    },
  ),
  rollScroll: field(
    () => rollScroll,
    (value) => {
      rollScroll = value;
    },
  ),
  activeView: field(
    () => activeView,
    (value) => {
      activeView = value;
    },
  ),
  commandIndex: field(
    () => commandIndex,
    (value) => {
      commandIndex = value;
    },
  ),
  pendingDeleteClipId: field(
    () => pendingDeleteClipId,
    (value) => {
      pendingDeleteClipId = value;
    },
  ),
  suppressSequencerClick: field(
    () => suppressSequencerClick,
    (value) => {
      suppressSequencerClick = value;
    },
  ),
  scratchBuffer: field(
    () => scratchBuffer,
    (value) => {
      scratchBuffer = value;
    },
  ),
  performanceTake: field(
    () => performanceTake,
    (value) => {
      performanceTake = value;
    },
  ),
  performanceStarted: field(
    () => performanceStarted,
    (value) => {
      performanceStarted = value;
    },
  ),
  performanceTimer: field(
    () => performanceTimer,
    (value) => {
      performanceTimer = value;
    },
  ),
  mixerReference: field(
    () => mixerReference,
    (value) => {
      mixerReference = value;
    },
  ),
  mixerComparing: field(
    () => mixerComparing,
    (value) => {
      mixerComparing = value;
    },
  ),
  activePerformanceTakeId: field(
    () => activePerformanceTakeId,
    (value) => {
      activePerformanceTakeId = value;
    },
  ),
  performanceEvents: field(
    () => performanceEvents,
    (value) => {
      performanceEvents = value;
    },
  ),
  exportController: field(
    () => exportController,
    (value) => {
      exportController = value;
    },
  ),
  launcherCapturing: field(
    () => launcherCapturing,
    (value) => {
      launcherCapturing = value;
    },
  ),
  launcherSnapshots: field(
    () => launcherSnapshots,
    (value) => {
      launcherSnapshots = value;
    },
  ),
  selectedScenes: field(
    () => selectedScenes,
    (value) => {
      selectedScenes = value;
    },
  ),
  sceneClipboard: field(
    () => sceneClipboard,
    (value) => {
      sceneClipboard = value;
    },
  ),
  mixerPeaks: field(
    () => mixerPeaks,
    (value) => {
      mixerPeaks = value;
    },
  ),
  clipStartSteps: field(() => clipStartSteps),
  samplerArmed: field(
    () => samplerArmed,
    (value) => {
      samplerArmed = value;
    },
  ),
  loadedSamplerAssetId: field(
    () => loadedSamplerAssetId,
    (value) => {
      loadedSamplerAssetId = value;
    },
  ),
  samplerQwertyBase: field(
    () => samplerQwertyBase,
    (value) => {
      samplerQwertyBase = value;
    },
  ),
  samplerHeld: field(() => samplerHeld),
  toastTimer: field(
    () => toastTimer,
    (value) => {
      toastTimer = value;
    },
  ),
  editorTool: field(
    () => editorTool,
    (value) => {
      editorTool = value;
    },
  ),
  soundPanel: field(
    () => soundPanel,
    (value) => {
      soundPanel = value;
    },
  ),
  language: field(
    () => language,
    (value) => {
      language = value;
    },
  ),
  tutorialStep: field(
    () => tutorialStep,
    (value) => {
      tutorialStep = value;
    },
  ),
  helpMode: field(
    () => helpMode,
    (value) => {
      helpMode = value;
    },
  ),
  L: field(() => L),
  history: field(() => history),
  engine: field(() => engine),
  presets: field(() => presets),
  keyMap: field(() => keyMap),
  pitchNames: field(() => pitchNames),
  samplerQwertyPitches: field(() => samplerQwertyPitches),
  samplerQwertyMap: field(() => samplerQwertyMap),
  loadProject: field(() => loadProject),
  esc: field(() => esc),
  snapshot: field(() => snapshot),
  changed: field(() => changed),
  toast: field(() => toast),
  download: field(() => download),
  quickHandles: field(() => quickHandles),
  QUICK_HANDLE_DB: field(() => QUICK_HANDLE_DB),
  LAST_EXPORT: field(() => LAST_EXPORT),
  quickHandleDb: field(() => quickHandleDb),
  ASSET_DB: field(() => ASSET_DB),
  assetDb: field(() => assetDb),
  putAsset: field(() => putAsset),
  getAsset: field(() => getAsset),
  deleteAsset: field(() => deleteAsset),
  renderExportTargets: field(() => renderExportTargets),
  showQuickHandle: field(() => showQuickHandle),
  loadQuickHandles: field(() => loadQuickHandles),
  rememberQuickHandle: field(() => rememberQuickHandle),
  forgetExportTarget: field(() => forgetExportTarget),
  prepareQuickExport: field(() => prepareQuickExport),
  writeQuickExport: field(() => writeQuickExport),
  quickExportProject: field(() => quickExportProject),
  safeName: field(() => safeName),
  clip: field(() => clip),
  pitches: field(() => pitches),
  staticCopy: field(() => staticCopy),
  leadingCopy: field(() => leadingCopy),
  shortcutCopy: field(() => shortcutCopy),
  controlDescriptions: field(() => controlDescriptions),
  applyLanguage: field(() => applyLanguage),
  controlInfo: field(() => controlInfo),
  installControlHelp: field(() => installControlHelp),
  showHelpIntro: field(() => showHelpIntro),
  toggleHelp: field(() => toggleHelp),
  showControlHelp: field(() => showControlHelp),
  tutorialSteps: field(() => tutorialSteps),
  showTutorialStep: field(() => showTutorialStep),
  startTutorial: field(() => startTutorial),
  endTutorial: field(() => endTutorial),
  initLearning: field(() => initLearning),
  renderTracks: field(() => renderTracks),
  renderInspector: field(() => renderInspector),
  applyPreset: field(() => applyPreset),
  renderArp: field(() => renderArp),
  renderFx: field(() => renderFx),
  macroMarkup: field(() => macroMarkup),
  renderClipControls: field(() => renderClipControls),
  updateDeleteClipDialog: field(() => updateDeleteClipDialog),
  requestClipDelete: field(() => requestClipDelete),
  renderHarmony: field(() => renderHarmony),
  renderPiano: field(() => renderPiano),
  bindMarqueeSelection: field(() => bindMarqueeSelection),
  bindNoteDrag: field(() => bindNoteDrag),
  syncSelectedClasses: field(() => syncSelectedClasses),
  syncRollScroll: field(() => syncRollScroll),
  setDefaultScroll: field(() => setDefaultScroll),
  renderSelection: field(() => renderSelection),
  editSelection: field(() => editSelection),
  deleteSelection: field(() => deleteSelection),
  renderAutomation: field(() => renderAutomation),
  heldKeyPointers: field(() => heldKeyPointers),
  releaseKeyPointer: field(() => releaseKeyPointer),
  releaseKeyPointers: field(() => releaseKeyPointers),
  instrumentOctave: field(
    () => instrumentOctave,
    (value) => {
      instrumentOctave = value;
    },
  ),
  renderKeyboard: field(() => renderKeyboard),
  startPerformance: field(() => startPerformance),
  endPerformance: field(() => endPerformance),
  launcherSnapshot: field(() => launcherSnapshot),
  launchClip: field(() => launchClip),
  renderLauncher: field(() => renderLauncher),
  setupLauncher: field(() => setupLauncher),
  renderArrangement: field(() => renderArrangement),
  sceneLength: field(() => sceneLength),
  focusScene: field(() => focusScene),
  updatePlayheads: field(() => updatePlayheads),
  updatePosition: field(() => updatePosition),
  updateOrb: field(() => updateOrb),
  songLength: field(() => songLength),
  formatLocator: field(() => formatLocator),
  setGlobalStart: field(() => setGlobalStart),
  setClipStart: field(() => setClipStart),
  renderLocators: field(() => renderLocators),
  syncLocatorsFromPlayback: field(() => syncLocatorsFromPlayback),
  renderMixer: field(() => renderMixer),
  animateMixer: field(() => animateMixer),
  updateScratchPlayButton: field(() => updateScratchPlayButton),
  armScratchBuffer: field(() => armScratchBuffer),
  importScratchFile: field(() => importScratchFile),
  audioRegionScratchBuffer: field(() => audioRegionScratchBuffer),
  loadAudioRegionIntoScratch: field(() => loadAudioRegionIntoScratch),
  captureScratchMix: field(() => captureScratchMix),
  animateScratchDeck: field(() => animateScratchDeck),
  setupScratchDeck: field(() => setupScratchDeck),
  performanceEventThrottle: field(() => performanceEventThrottle),
  performanceStep: field(() => performanceStep),
  recordPerformanceEvent: field(() => recordPerformanceEvent),
  loadPerformanceAudio: field(() => loadPerformanceAudio),
  applyPerformanceEvent: field(() => applyPerformanceEvent),
  playPerformanceTake: field(() => playPerformanceTake),
  openTakeEditor: field(() => openTakeEditor),
  renderPerformanceTakes: field(() => renderPerformanceTakes),
  togglePerformanceCapture: field(() => togglePerformanceCapture),
  mixSnapshot: field(() => mixSnapshot),
  captureMixerReference: field(() => captureMixerReference),
  toggleMixerReference: field(() => toggleMixerReference),
  setupArrangeTools: field(() => setupArrangeTools),
  USER_PRESETS: field(() => USER_PRESETS),
  PRESET_FAVORITES: field(() => PRESET_FAVORITES),
  userPresets: field(() => userPresets),
  saveUserPresets: field(() => saveUserPresets),
  presetFavorites: field(() => presetFavorites),
  renderPresetLibrary: field(() => renderPresetLibrary),
  saveCurrentPreset: field(() => saveCurrentPreset),
  loadLocalSample: field(() => loadLocalSample),
  loadLocalSamples: field(() => loadLocalSamples),
  renderSampleSlots: field(() => renderSampleSlots),
  setupLibraries: field(() => setupLibraries),
  setupPrecisionControls: field(() => setupPrecisionControls),
  setupStudioExtensions: field(() => setupStudioExtensions),
  readUiPrefs: field(() => readUiPrefs),
  writeUiPrefs: field(() => writeUiPrefs),
  setRackCollapsed: field(() => setRackCollapsed),
  toggleFocus: field(() => toggleFocus),
  selectTrack: field(() => selectTrack),
  commands: field(() => commands),
  matchingCommands: field(() => matchingCommands),
  renderCommands: field(() => renderCommands),
  runCommand: field(() => runCommand),
  openCommands: field(() => openCommands),
  initWorkflowUi: field(() => initWorkflowUi),
  renderVersions: field(() => renderVersions),
  loadVersions: field(() => loadVersions),
  saveVersion: field(() => saveVersion),
  inputRecorder: field(
    () => inputRecorder,
    (value) => {
      inputRecorder = value;
    },
  ),
  inputStream: field(
    () => inputStream,
    (value) => {
      inputStream = value;
    },
  ),
  inputChunks: field(
    () => inputChunks,
    (value) => {
      inputChunks = value;
    },
  ),
  midiLearnTarget: field(
    () => midiLearnTarget,
    (value) => {
      midiLearnTarget = value;
    },
  ),
  applyMidiMapping: field(() => applyMidiMapping),
  audioBufferWav: field(() => audioBufferWav),
  addAudioBlob: field(() => addAudioBlob),
  loadAudioAssets: field(() => loadAudioAssets),
  renderAudioStudio: field(() => renderAudioStudio),
  renderGlobalAutomation: field(() => renderGlobalAutomation),
  renderMixGroups: field(() => renderMixGroups),
  renderTempoMap: field(() => renderTempoMap),
  samplerSettings: field(() => samplerSettings),
  setupSamplerOctaveControls: field(() => setupSamplerOctaveControls),
  samplerNoteName: field(() => samplerNoteName),
  drawSamplerWaveform: field(() => drawSamplerWaveform),
  startSamplerPerformance: field(() => startSamplerPerformance),
  endSamplerPerformance: field(() => endSamplerPerformance),
  renderSamplerKeyboard: field(() => renderSamplerKeyboard),
  loadSamplerAsset: field(() => loadSamplerAsset),
  setupSamplerKeyboard: field(() => setupSamplerKeyboard),
  setupV6Studio: field(() => setupV6Studio),
  setupMidiLearnUi: field(() => setupMidiLearnUi),
  setupV6Copy: field(() => setupV6Copy),
  setupV6Safety: field(() => setupV6Safety),
  setupSampleSlicing: field(() => setupSampleSlicing),
  setupProjectTemplates: field(() => setupProjectTemplates),
  renderAll: field(() => renderAll),
  syncTransportButtons: field(() => syncTransportButtons),
  pausePlayback: field(() => pausePlayback),
  togglePlay: field(() => togglePlay),
  animateMeter: field(() => animateMeter),
  wavOptions: field(() => wavOptions),
  setExportProgress: field(() => setExportProgress),
  exportWav: field(() => exportWav),
  crc32: field(() => crc32),
  zipFiles: field(() => zipFiles),
  readStoreZip: field(() => readStoreZip),
  importProjectFile: field(() => importProjectFile),
  renderStems: field(() => renderStems),
  renderProjectBundle: field(() => renderProjectBundle),
  exportMeta: field(() => exportMeta),
  exportName: field(() => exportName),
  performExport: field(() => performExport),
  quickExportWav: field(() => quickExportWav),
  quickExportMidi: field(() => quickExportMidi),
  repeatLastExport: field(() => repeatLastExport),
  activateView: field(() => activateView),
  compatibility: field(() => compatibility),
  showCompatibility: field(() => showCompatibility),
  open: field(() => open),
  replaceProject: field(() => replaceProject),
  initMidi: field(() => initMidi),
  query: field(() => query),
  copyQueued: field(
    () => copyQueued,
    (value) => {
      copyQueued = value;
    },
  ),
  syncStudioUi: field(() => syncStudioUi),
  duplicateSelectedNotes: field(() => duplicateSelectedNotes),
  quantizeSelectedNotes: field(() => quantizeSelectedNotes),
  setupStudioUi: field(() => setupStudioUi),
  setupConsistentControls: field(() => setupConsistentControls),
});
export type RuntimeContext = typeof runtime;
import { t as msg, translateDOM, translate } from "./ui/i18n";
import { releaseAllKeyboards } from "./ui/components/keyboard";

import { studioBridge, type StudioView } from "./ui/bridge";
import {
  createProject,
  createEmptyProject,
  migrateProject,
  activeClip,
  clipsForTrack,
  createClip,
  clipLengthSteps,
  meterSteps,
  setProjectMeter,
  duplicateClip,
  deleteClip,
  varyClip,
  generateBacking,
  History,
  addArrangementScene,
  distributeArrangementPatterns,
  cryptoId,
} from "./core.js";
import { AudioEngine } from "./audio.js";
import type {
  AudioLane,
  AudioRegion,
  MidiMapping,
  NoteEvent,
  NoteExpression,
  PerformanceEvent,
  PerformanceTake,
  Project,
  SampleAsset,
  SamplerInstrument,
  TrackId,
} from "./model.js";

declare global {
  interface Window {
    __kvErrors: string[];
    __kvDiagnostics: () => ReturnType<AudioEngine["diagnostics"]>;
    webkitAudioContext?: typeof AudioContext;
    showSaveFilePicker?: (options: Record<string, unknown>) => Promise<any>;
  }
}

window.__kvErrors = [];
function reportError(message: unknown): any {
  return workflow.reportError(runtime, message);
}
function reportPageError(input: PageErrorInput) {
  const diagnostic = recordPageError(input, window.location.href);
  if (diagnostic.origin === "application") reportError(diagnostic.message);
}
window.addEventListener("error", (event) =>
  reportPageError({
    kind: "error",
    message: event.message,
    source: event.filename,
    line: event.lineno,
    column: event.colno,
    error: event.error,
  }),
);
window.addEventListener("unhandledrejection", (event) =>
  reportPageError({ kind: "rejection", error: event.reason }),
);

const $ = (s: string): any => document.querySelector(s),
  $$ = (s: string): any[] => [...document.querySelectorAll(s)],
  STORAGE = "kiber-vengance-project-v7",
  LEGACY_V6 = "kiber-vengance-project-v6",
  LEGACY_V5 = "kiber-vengance-project-v5",
  LEGACY_V4 = "kiber-vengance-project-v4",
  LEGACY_V3 = "kiber-vengance-project-v3",
  LEGACY = "kiber-vengance-project-v2",
  VERSIONS = "kiber-vengance-versions-v1",
  UI_STORAGE = "kiber-vengance-ui-v1",
  LANGUAGE_STORAGE = "kiber-vengance-language-v1";
let copyQueued = false;
let autosaveRecoveryBlocked = false;
let autosaveRecoveryNotice = false;
const projectRepository = new ProjectRepository();
let project: Project = await loadProject(),
  selectedTrack: TrackId = "lead",
  selectedNotes = new Set<string>(),
  currentStep = -1,
  currentScene = -1,
  transportPosition = 0,
  globalStartStep = 0,
  draggedScene = -1,
  recordArmed = false,
  metronome = false,
  animation = 0,
  clipboard: NoteEvent[] = [],
  recording = new Map<string, any>(),
  rollScroll: any = {},
  activeView = "forge",
  commandIndex = 0,
  pendingDeleteClipId: string | null = null,
  suppressSequencerClick = false,
  scratchBuffer: AudioBuffer | null = null,
  performanceTake: Blob | null = null,
  performanceStarted = 0,
  performanceTimer: ReturnType<typeof setInterval> | null = null,
  mixerReference: any = null,
  mixerComparing = false,
  activePerformanceTakeId: string | null = null,
  performanceEvents: PerformanceEvent[] | null = null,
  exportController: AbortController | null = null,
  launcherCapturing = false,
  launcherSnapshots: Array<{
    name: string;
    clipIds: Record<TrackId, string>;
    repeats: number;
  }> = [],
  selectedScenes = new Set<number>(),
  sceneClipboard: any[] = [],
  mixerPeaks: Partial<Record<TrackId, number>> = {};
const clipStartSteps = new Map<string, number>();
let samplerArmed = false,
  loadedSamplerAssetId: string | null = null,
  samplerQwertyBase = 60;
const samplerHeld = new Map<string, HTMLElement>();
let toastTimer: ReturnType<typeof setTimeout>;
let editorTool: "draw" | "select" | "navigate" = "draw";
let soundPanel = false;
type Language = "en" | "es";
let language: Language =
    localStorage.getItem(LANGUAGE_STORAGE) === "es" ? "es" : "en",
  tutorialStep = 0,
  helpMode = false;
const L = translate;
const history = new History<Project>();
const engine = new AudioEngine(
  (
    step: number,
    time: number,
    scene: number,
    info: Record<string, any> = {},
  ) => {
    if (step === -2) {
      $("#audioState").textContent = `COUNT ${info.countIn}`;
      return;
    }
    currentStep = step;
    currentScene = scene;
    if (step >= 0) transportPosition = Number(info.position ?? step);
    if (step < 0) $("#audioState").textContent = "STANDBY";
    else $("#audioState").textContent = "RUNNING";
    requestAnimationFrame(() => {
      updatePlayheads();
      updatePosition();
      syncLocatorsFromPlayback();
    });
  },
);
engine.project = project;
window.__kvDiagnostics = () => engine.diagnostics();
engine.onScratchGesture = (target: string, value: number | boolean) =>
  recordPerformanceEvent("scratch", target, value);
const presets = {
  lead: ["Razor Choir", "Neon Talon", "Solar Vengeance"],
  guitar: ["Chrome Strings", "Voltage Chug", "Glass Horizon"],
  bass: ["Foundry Pulse", "Black Reactor", "Grind Theory"],
  pad: ["Afterlight", "Frozen Cathedral", "Signal Ghost"],
  drums: ["Titan Frame", "Riot Assembly", "Chrome Bones"],
};
const keyMap = "awsedftgyhujk",
  drumKeyMap = "asdfghj",
  pitchNames = [
    "C",
    "C♯",
    "D",
    "D♯",
    "E",
    "F",
    "F♯",
    "G",
    "G♯",
    "A",
    "A♯",
    "B",
  ],
  samplerQwertyPitches = [60, 62, 64, 65, 67, 69, 71, 72],
  samplerQwertyMap: Record<string, number> = {
    a: 0,
    w: 1,
    s: 2,
    e: 3,
    d: 4,
    f: 5,
    t: 6,
    g: 7,
    y: 8,
    h: 9,
    u: 10,
    j: 11,
    k: 12,
  };

async function loadProject() {
  try {
    const stored = await projectRepository.load();
    if (projectRepository.recoveryNotices.length) autosaveRecoveryNotice = true;
    if (stored) return migrateProject(stored);
  } catch {
    autosaveRecoveryNotice = true;
    try {
      await projectRepository.quarantineCurrent();
      for (const version of await projectRepository.listVersions()) {
        try {
          const recovered = await projectRepository.getVersion(version.id);
          if (recovered) return migrateProject(recovered);
        } catch {
          /* Try the next readable snapshot. */
        }
      }
    } catch {
      autosaveRecoveryBlocked = true;
    }
  }
  for (const key of [
    STORAGE,
    LEGACY_V6,
    LEGACY_V5,
    LEGACY_V4,
    LEGACY_V3,
    LEGACY,
  ])
    try {
      const value = localStorage.getItem(key);
      if (value) return migrateProject(JSON.parse(value));
    } catch {
      autosaveRecoveryNotice = true;
      // Preserve the unreadable source before a later autosave can replace it.
      try {
        const raw = localStorage.getItem(key);
        if (raw) localStorage.setItem(`${key}-unreadable-${Date.now()}`, raw);
      } catch {
        // Keep the source key untouched when even a recovery copy cannot fit.
        autosaveRecoveryBlocked = true;
      }
    }
  return createProject();
}
function esc(v: any) {
  return String(v).replace(
    /[&<>'"]/g,
    (c) =>
      (
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          "'": "&#39;",
          '"': "&quot;",
        }) as Record<string, string>
      )[c]!,
  );
}
const projectSession = new ProjectSession(() => project, history, {
  async save(value) {
    if (autosaveRecoveryBlocked)
      throw new Error("Unreadable autosave could not be preserved");
    await projectRepository.save(value);
  },
  key: STORAGE,
  status(state) {
    $("#saveState").textContent = msg(
      state === "pending"
        ? "ui_56a2285c5b11"
        : state === "saved"
          ? "ui_87222e82bf5d"
          : "ui_3d56409d02fb",
    );
    const warning = $("#saveWarning");
    if (warning && state !== "pending") {
      warning.hidden = state !== "failed";
      if (state === "failed") warning.textContent = msg("ui_008e26ff915f");
    }
  },
  recovery(project) {
    return projectRepository.saveVersion(
      project,
      `AUTO RECOVERY · ${project.title}`,
    );
  },
  recoveryFailed() {
    toast(msg("ui_0af7730f9e25"));
  },
});
function snapshot() {
  projectSession.checkpoint();
}
function beginProjectEdit() {
  return projectSession.beginEdit(() => changed());
}
function changed(render = false) {
  projectSession.changed();
  engine.setProject(project);
  if (project.sampler?.assetId !== loadedSamplerAssetId)
    void loadSamplerAsset();
  if (render) renderAll();
  syncStudioUi();
}
function toast(message: any, undo = false) {
  clearTimeout(toastTimer);
  const el = $("#toast");
  el.textContent = message;
  if (undo) {
    const button = document.createElement("button");
    button.textContent = msg("ui_39fc72124884");
    button.onclick = () => {
      $("#undoBtn").click();
      el.classList.remove("show");
    };
    el.append(button);
  }
  el.classList.add("show");
  toastTimer = setTimeout(
    () => el.classList.remove("show"),
    undo ? 6000 : 2500,
  );
}
function download(
  data: any,
  name: string,
  type = "application/octet-stream",
): any {
  return storage.download(runtime, data, name, type);
}
type QuickExportKind =
  | "ogg"
  | "wav"
  | "midi"
  | "project"
  | "clip-wav"
  | "clip-midi"
  | "stems"
  | "bundle"
  | "performance";
type QuickTarget = {
  handle: any | null;
  fallback: boolean;
  cancelled: boolean;
  name: string;
  type: string;
};
const quickHandles = new Map<QuickExportKind, any>(),
  QUICK_HANDLE_DB = "kiber-vengance-file-handles-v1",
  LAST_EXPORT = "kiber-vengance-last-export-v1";
function quickHandleDb(): any {
  return workflow.quickHandleDb(runtime);
}
const ASSET_DB = "kiber-vengance-assets-v1";
function assetDb(): any {
  return storage.assetDb(runtime);
}
async function putAsset(id: string, blob: Blob): Promise<any> {
  return storage.putAsset(runtime, id, blob);
}
async function getAsset(id: string): Promise<any> {
  return storage.getAsset(runtime, id);
}
async function deleteAsset(id: string): Promise<any> {
  return storage.deleteAsset(runtime, id);
}
function renderExportTargets(): any {
  return storage.renderExportTargets(runtime);
}
function showQuickHandle(_kind: QuickExportKind, _handle: any): any {
  return workflow.showQuickHandle(runtime, _kind, _handle);
}
async function loadQuickHandles(): Promise<any> {
  return workflow.loadQuickHandles(runtime);
}
async function rememberQuickHandle(
  kind: QuickExportKind,
  handle: any,
): Promise<any> {
  return workflow.rememberQuickHandle(runtime, kind, handle);
}
async function forgetExportTarget(kind: QuickExportKind): Promise<any> {
  return storage.forgetExportTarget(runtime, kind);
}
async function prepareQuickExport(
  kind: QuickExportKind,
  name: string,
  type: string,
  extension: string,
  description: string,
  forcePicker = false,
): Promise<QuickTarget> {
  return storage.prepareQuickExport(
    runtime,
    kind,
    name,
    type,
    extension,
    description,
    forcePicker,
  );
}
async function writeQuickExport(target: QuickTarget, data: any): Promise<any> {
  return storage.writeQuickExport(runtime, target, data);
}
async function quickExportProject(forcePicker = false): Promise<any> {
  return storage.quickExportProject(runtime, forcePicker);
}
function safeName(): any {
  return storage.safeName(runtime);
}
function clip() {
  return activeClip(project, selectedTrack);
}
function pitches(): any {
  return performanceFeature.pitches(runtime);
}

const staticCopy: Array<[string, string, string]> = [
  ["#boot p", "LOADING COMPOSITION ENGINE", "CARGANDO MOTOR DE COMPOSICIÓN"],
  [".project-head label", "PROJECT", "PROYECTO"],
  [".rail-label", "INDEPENDENT CLIPS", "CLIPS INDEPENDIENTES"],
  ["#newClipBtn", "＋ NEW CLIP", "＋ NUEVO CLIP"],
  ['[data-view="forge"]', "FORGE", "FORJA"],
  ['[data-view="arrange"]', "ARRANGE", "ARREGLO"],
  ['[data-view="perform"]', "PERFORM", "INTERPRETAR"],
  ["#tutorialBtn", "GUIDE", "GUÍA"],
  ["#focusBtn", "FOCUS", "FOCO"],
  ["#motionRack .eyebrow", "MOTION ENGINE", "MOTOR DE MOVIMIENTO"],
  ["#effectsRack .eyebrow", "SIGNAL PROCESSING", "PROCESADO DE SEÑAL"],
  ["#effectsRack strong", "TRACK FX", "EFECTOS DE PISTA"],
  ["#macroRack .eyebrow", "VECTOR CONTROL", "CONTROL VECTORIAL"],
  ["#macroRack strong", "SCULPT THE IMPACT", "MODELA EL IMPACTO"],
  ["#fxBypass", "BYPASS", "OMITIR"],
  [".editor-head .eyebrow", "ACTIVE CLIP", "CLIP ACTIVO"],
  ["#duplicateBtn", "DUPLICATE", "DUPLICAR"],
  ["#mutateBtn", "MUTATE", "MUTAR"],
  ["#backingBtn", "BACKING", "BASE"],
  ["#quantizeBtn", "QUANTIZE", "CUANTIZAR"],
  ["#deleteNotesBtn", "DELETE", "BORRAR"],
  [".automation-head .eyebrow", "AUTOMATION", "AUTOMATIZACIÓN"],
  [
    ".automation-head>span",
    "CLICK / DRAG TO DRAW",
    "CLIC / ARRASTRA PARA DIBUJAR",
  ],
  ["#clearAutomationBtn", "CLEAR LANE", "LIMPIAR LÍNEA"],
  [
    "#arrangeDescription",
    "Each section combines independent clips. Edit, repeat and reorder the complete song.",
    "Cada sección combina clips independientes. Edita, repite y reordena la canción completa.",
  ],
  ["#addSceneBtn", "＋ ADD SECTION", "＋ AÑADIR SECCIÓN"],
  ["#autoArrangeBtn", "⟳ AUTO SEQUENCE", "⟳ SECUENCIA AUTO"],
  [
    "#performDescription",
    "Play the instruments, capture the active mix, and cut it into the performance with the Scratch Deck.",
    "Toca los instrumentos, captura la mezcla activa y córtala en directo con el plato de scratch.",
  ],
  ["#backingDialog .eyebrow", "BACKING GENERATOR", "GENERADOR DE BASES"],
  [
    "#backingDialog h2",
    "BUILD A PLAYABLE FOUNDATION",
    "CREA UNA BASE PARA TOCAR",
  ],
  [
    "#backingDescription",
    "Generate a structured bass, pad and drum arrangement while preserving your lead and guitar clips.",
    "Genera un arreglo estructurado de bajo, pad y batería conservando tus clips de lead y guitarra.",
  ],
  [
    "#backingWarning",
    "The current arrangement will be replaced. You can undo this action.",
    "El arreglo actual será reemplazado. Puedes deshacer esta acción.",
  ],
  ["#generateBackingBtn", "GENERATE BACKING", "GENERAR BASE"],
  ["#projectMenu .eyebrow", "PROJECT CORE", "NÚCLEO DEL PROYECTO"],
  ["#projectMenu h2", "Project & settings", "Proyecto y ajustes"],
  ["#menuLanguageLabel", "INTERFACE LANGUAGE", "IDIOMA DE LA INTERFAZ"],
  ["#importProjectLabel", "Import project JSON", "Importar proyecto JSON"],
  ["#newBtn", "New demo project", "Nuevo proyecto de demostración"],
  ["#emptyBtn", "New empty project", "Nuevo proyecto vacío"],
  [
    "#duplicateProjectBtn",
    "Duplicate current project",
    "Duplicar proyecto actual",
  ],
  ["#saveBtn", "Create named snapshot", "Crear instantánea con nombre"],
  ["#exportProjectBtn", "Export project JSON", "Exportar proyecto JSON"],
  ["#compatBtn", "Compatibility report", "Informe de compatibilidad"],
  [".versions-head", "LOCAL VERSIONS", "VERSIONES LOCALES"],
  [
    "#exportDialog .eyebrow",
    "COMMIT THE FULL SIGNAL",
    "CONSOLIDA TODA LA SEÑAL",
  ],
  ["#exportDialog h2", "EXPORT SONG", "EXPORTAR CANCIÓN"],
  [
    "#exportDialog>p",
    "Render the complete arrangement, including repeated clips, automation, arpeggiators and effects.",
    "Renderiza todo el arreglo, incluidos clips repetidos, automatización, arpegiadores y efectos.",
  ],
  ["#wavBtn b", "SONG WAV", "CANCIÓN WAV"],
  ["#exportMidiBtn b", "SONG MIDI", "CANCIÓN MIDI"],
  ["#clipWavBtn b", "CLIP WAV", "CLIP WAV"],
  ["#clipMidiBtn b", "CLIP MIDI", "CLIP MIDI"],
  ["#helpDialog .eyebrow", "FIELD MANUAL", "MANUAL DE CAMPO"],
  ["#helpDialog h2", "COMPOSITION CONTROLS", "CONTROLES DE COMPOSICIÓN"],
  [
    "#helpDialog .note",
    "Drag notes to move them and use the handle on their right edge to resize. Web MIDI records note-on/off, velocity, bend, pressure and timbre.",
    "Arrastra las notas para moverlas y usa el tirador derecho para cambiar su duración. Web MIDI graba nota, velocidad, bend, presión y timbre.",
  ],
  [
    "#aboutDialog p",
    "A complete cinematic electro-rock composition engine built for pressure, motion and controlled impact.",
    "Un motor completo de composición electro-rock cinematográfica creado para presión, movimiento e impacto controlado.",
  ],
  ["#compatDialog .eyebrow", "SYSTEM DIAGNOSTICS", "DIAGNÓSTICO DEL SISTEMA"],
  ["#compatDialog h2", "COMPATIBILITY REPORT", "INFORME DE COMPATIBILIDAD"],
  ["#copyCompatBtn", "COPY REPORT", "COPIAR INFORME"],
  [
    "#commandDialog .command-head .eyebrow",
    "RAPID EXECUTION",
    "EJECUCIÓN RÁPIDA",
  ],
  ["#commandDialog .command-head b", "COMMAND PALETTE", "PALETA DE COMANDOS"],
  [
    ".command-help",
    "↑↓ NAVIGATE · ENTER EXECUTE · ESC CLOSE",
    "↑↓ NAVEGAR · INTRO EJECUTAR · ESC CERRAR",
  ],
  ["#contextHelpEyebrow", "CONTEXT HELP", "AYUDA CONTEXTUAL"],
  ["#manualBtn", "KEYBOARD SHORTCUTS", "ATAJOS DE TECLADO"],
];
staticCopy.push(
  ["#effectsRack strong", "CLIP FX", "EFECTOS DEL CLIP"],
  ["#motionRack .clip-scope", "ACTIVE CLIP", "CLIP ACTIVO"],
  ["#effectsRack .clip-scope", "ACTIVE CLIP", "CLIP ACTIVO"],
  ["#macroRack .clip-scope", "ACTIVE CLIP", "CLIP ACTIVO"],
  [".backing-options label:nth-child(1)>span", "STYLE", "ESTILO"],
  [".backing-options label:nth-child(2)>span", "SECTIONS", "SECCIONES"],
  [".backing-options label:nth-child(3)>span", "INTENSITY", "INTENSIDAD"],
  ["#deleteClipDialog .eyebrow", "DESTRUCTIVE EDIT", "EDICIÓN DESTRUCTIVA"],
  [
    "#deleteClipDialog .delete-clip-warning",
    "This removes the clip from the project. You can undo this action.",
    "Esto elimina el clip del proyecto. Puedes deshacer la acción.",
  ],
  ["#cancelDeleteClipBtn", "CANCEL", "CANCELAR"],
  ["#confirmDeleteClipBtn", "DELETE CLIP", "BORRAR CLIP"],
);
staticCopy.push(
  ["#scratchTitle", "SCRATCH DECK", "PLATO DE SCRATCH"],
  ["#scratchCaptureBtn", "CAPTURE MIX", "CAPTURAR MEZCLA"],
  [".scratch-import span", "IMPORT AUDIO", "IMPORTAR AUDIO"],
  ["#scratchBrakeBtn", "BRAKE", "FRENAR"],
  ["#scratchSpinBtn", "↶ SPINBACK", "↶ RETROCESO"],
  ["#scratchStutterBtn", "STUTTER", "REPETIR"],
  [
    ".scratch-hint",
    "Drag the vinyl in either direction. Release for motor return; wheel or ← → for precise cuts.",
    "Arrastra el vinilo en ambas direcciones. Suelta para recuperar el motor; usa la rueda o ← → para cortes precisos.",
  ],
);
staticCopy.push(
  ['[data-view="mix"]', "MIX", "MEZCLA"],
  ["#exportAsBtn", "EXPORT AS", "EXPORTAR COMO"],
  ["#globalStartBtn", "▶ SONG", "▶ CANCIÓN"],
  [
    "#arrangeDescription",
    "Each section combines independent clips. Click the timeline to set the global start; edit, repeat and reorder the complete song.",
    "Cada sección combina clips independientes. Pulsa la línea temporal para fijar el inicio global; edita, repite y reordena la canción.",
  ],
  ["#exportDialog h2", "EXPORT / EXPORT AS", "EXPORTAR / EXPORTAR COMO"],
  [
    "#exportDialog>p",
    "Export reuses the linked file. Export As always asks for a new destination.",
    "Exportar reutiliza el archivo vinculado. Exportar como siempre solicita un destino nuevo.",
  ],
  [".export-targets-head", "EXPORT DESTINATIONS", "DESTINOS DE EXPORTACIÓN"],
  [
    "#forgetTargetsBtn",
    "Forget all destinations",
    "Olvidar todos los destinos",
  ],
  ["#mixCaptureBtn", "CAPTURE A", "CAPTURAR A"],
  ["#mixCompareBtn", "COMPARE B", "COMPARAR B"],
  ["#performanceRecordBtn", "● RECORD TAKE", "● GRABAR TOMA"],
  ["#performanceSaveBtn", "SAVE TAKE AS", "GUARDAR TOMA COMO"],
);
staticCopy.push(
  ['[data-view="launch"]', "LAUNCH", "LANZAR"],
  ["#launchView h1", "CLIP LAUNCHER", "LANZADOR DE CLIPS"],
  [
    "#launchView .launcher-head p",
    "Queue clips without stopping the signal, stop individual tracks, and capture the live sequence into Arrange.",
    "Pon clips en cola sin detener la señal, para pistas individuales y captura la secuencia en directo en Arreglo.",
  ],
  ["#launcherCaptureBtn", "● CAPTURE", "● CAPTURAR"],
  ["#launcherCommitBtn", "COMMIT TO ARRANGE", "ENVIAR AL ARREGLO"],
  ["#arrangeSelectAllBtn", "SELECT ALL", "SELECCIONAR TODO"],
  ["#arrangeDuplicateBtn", "DUPLICATE", "DUPLICAR"],
  ["#arrangeCopyBtn", "COPY", "COPIAR"],
  ["#arrangePasteBtn", "PASTE", "PEGAR"],
  ["#arrangeDeleteBtn", "DELETE", "BORRAR"],
  ["#arrangeFillBtn", "＋ FILL", "＋ FILL"],
  ["#arrangeMarkerBtn", "＋ MARKER", "＋ MARCADOR"],
  ["#masterBypassBtn", "MASTER FX", "FX MASTER"],
  ["#presetLibraryBtn", "Preset library", "Biblioteca de presets"],
  ["#sampleLibraryBtn", "Local drum samples", "Samples de batería locales"],
  ["#compactModeBtn", "Compact workspace", "Espacio compacto"],
  ["#presetDialog h2", "PRESET VAULT", "CÁMARA DE PRESETS"],
  ["#sampleDialog h2", "IMPACT SAMPLE SLOTS", "RANURAS DE SAMPLES IMPACT"],
  ["#saveUserPresetBtn", "＋ SAVE CURRENT", "＋ GUARDAR ACTUAL"],
  ["#exportPresetBankBtn", "EXPORT BANK", "EXPORTAR BANCO"],
  ["#takeQuantizeBtn", "QUANTIZE EVENTS", "CUANTIZAR EVENTOS"],
  ["#cancelExportBtn", "CANCEL", "CANCELAR"],
);
const leadingCopy: Array<[string, string, string]> = [
  ["label:has(#barsSelect)", "BARS", "COMPASES"],
  ["label:has(#gridSelect)", "SNAP", "AJUSTE"],
  ["label:has(#zoomRange)", "ZOOM", "ZOOM"],
  ["label:has(#keySelect)", "KEY", "TONALIDAD"],
  ["label:has(#scaleSelect)", "SCALE", "ESCALA"],
  ["label:has(#noteLength)", "LEN", "DUR"],
  ["label:has(#noteVelocity)", "VEL", "VEL"],
  ["label:has(#arpMode)", "MODE", "MODO"],
  ["label:has(#arpOctaves)", "OCT", "OCT"],
  ["label:has(#arpRate)", "RATE", "RITMO"],
  ["label:has(#lfoTarget)", "TARGET", "DESTINO"],
  ["label:has(#lfoRate)", "LFO RATE", "RITMO LFO"],
  ["label:has(#lfoDepth)", "DEPTH", "PROFUNDIDAD"],
];
const shortcutCopy: Array<[string, string]> = [
  ["Play / stop from locator", "Reproducir / parar desde el localizador"],
  ["Perform / record", "Interpretar / grabar"],
  ["Select track", "Seleccionar pista"],
  ["Command palette", "Paleta de comandos"],
  ["Export to current destination", "Exportar al destino actual"],
  ["Open Export As", "Abrir Exportar como"],
  ["Toggle Focus mode", "Activar modo Foco"],
  [
    "Forge / Launch / Arrange / Mix / Perform",
    "Forja / Lanzar / Arreglo / Mezcla / Interpretar",
  ],
  ["New / duplicate clip", "Nuevo / duplicar clip"],
  ["Solo / mute active track", "Solo / silenciar pista activa"],
  ["Mutate / quantize", "Mutar / cuantizar"],
  ["Undo / redo", "Deshacer / rehacer"],
  ["Multi-select notes", "Selección múltiple"],
  ["Select all notes", "Seleccionar todas las notas"],
  ["Move selected notes", "Mover notas seleccionadas"],
  ["Resize selected notes", "Redimensionar notas"],
  ["Copy / paste notes", "Copiar / pegar notas"],
  ["Delete selection", "Borrar selección"],
];
const controlDescriptions: Record<string, [string, string, string, string]> = {
  aboutBtn: [
    "Brand & about",
    "Marca e información",
    "Open product information and version details.",
    "Abre la información del producto y sus detalles.",
  ],
  title: [
    "Project title",
    "Título del proyecto",
    "Rename the current project. Changes are saved locally.",
    "Renombra el proyecto actual. Los cambios se guardan localmente.",
  ],
  rewindBtn: [
    "Return to start",
    "Volver al inicio",
    "Stop playback and return the playhead to the beginning.",
    "Detiene la reproducción y devuelve el cursor al inicio.",
  ],
  playBtn: [
    "Play / stop",
    "Reproducir / parar",
    "Start or stop the active clip or full arrangement. Shortcut: Space.",
    "Inicia o detiene el clip activo o el arreglo completo. Atajo: Espacio.",
  ],
  pauseBtn: [
    "Pause at playhead",
    "Pausar en el cursor",
    "Pause playback and preserve the current position so Play resumes from there.",
    "Pausa la reproducción y conserva la posición para continuar desde ahí.",
  ],
  recordBtn: [
    "Record arm",
    "Armar grabación",
    "Arm live recording from the computer keyboard, touch keys or MIDI.",
    "Prepara la grabación en directo desde teclado, controles táctiles o MIDI.",
  ],
  recordMode: [
    "Recording timing",
    "Temporización de grabación",
    "Choose quantized timing or preserve free microtiming.",
    "Elige tiempo cuantizado o conserva el microtiming libre.",
  ],
  tempo: [
    "Tempo",
    "Tempo",
    "Set song speed in beats per minute.",
    "Ajusta la velocidad de la canción en pulsos por minuto.",
  ],
  meterSelect: [
    "Time signature",
    "Compás",
    "Choose the rhythmic meter used by clips and bars.",
    "Elige el compás rítmico utilizado por clips y barras.",
  ],
  swing: [
    "Swing",
    "Swing",
    "Delay alternating subdivisions to add groove.",
    "Retrasa subdivisiones alternas para añadir groove.",
  ],
  countIn: [
    "Count-in",
    "Cuenta atrás",
    "Choose how many bars play before armed recording starts.",
    "Elige cuántos compases suenan antes de iniciar la grabación.",
  ],
  metroBtn: [
    "Metronome",
    "Metrónomo",
    "Toggle the accented timing click during playback.",
    "Activa o desactiva el clic acentuado durante la reproducción.",
  ],
  masterVolume: [
    "Program volume",
    "Volumen de Program",
    "Set the song level before the final Master and deck blend.",
    "Ajusta la canción antes del Master final y el balance con los platos.",
  ],
  languageSelect: [
    "Language",
    "Idioma",
    "Switch the complete interface between English and Spanish.",
    "Cambia toda la interfaz entre inglés y español.",
  ],
  exportBtn: [
    "Export",
    "Exportar",
    "Render the song or active clips to WAV or MIDI.",
    "Renderiza la canción o los clips activos a WAV o MIDI.",
  ],
  menuBtn: [
    "Project menu",
    "Menú del proyecto",
    "Create, import, export or restore project versions.",
    "Crea, importa, exporta o restaura versiones del proyecto.",
  ],
  tutorialBtn: [
    "Interactive guide",
    "Guía interactiva",
    "Start a guided tour through the complete composition workflow.",
    "Inicia un recorrido guiado por todo el flujo de composición.",
  ],
  focusBtn: [
    "Focus mode",
    "Modo Foco",
    "Hide secondary racks and dedicate more space to note editing.",
    "Oculta paneles secundarios y dedica más espacio a editar notas.",
  ],
  commandBtn: [
    "Command palette",
    "Paleta de comandos",
    "Search and execute any common action from the keyboard.",
    "Busca y ejecuta acciones habituales desde el teclado.",
  ],
  undoBtn: [
    "Undo",
    "Deshacer",
    "Restore the previous musical edit.",
    "Restaura la edición musical anterior.",
  ],
  redoBtn: [
    "Redo",
    "Rehacer",
    "Reapply the last undone edit.",
    "Vuelve a aplicar la última edición deshecha.",
  ],
  helpBtn: [
    "Context help",
    "Ayuda contextual",
    "Show a live explanation whenever a control is focused or touched.",
    "Muestra una explicación cuando enfocas o tocas un control.",
  ],
  preset: [
    "Sound preset",
    "Preset de sonido",
    "Load a sound for the active clip. Track level and pan stay unchanged.",
    "Carga un sonido para el clip activo. El nivel y panorama de la pista se conservan.",
  ],
  waveSelect: [
    "Main oscillator",
    "Oscilador principal",
    "Choose the waveform that defines the core timbre.",
    "Elige la forma de onda que define el timbre principal.",
  ],
  osc2WaveSelect: [
    "Second oscillator",
    "Segundo oscilador",
    "Choose an additional waveform or switch oscillator two off.",
    "Elige una onda adicional o desactiva el segundo oscilador.",
  ],
  filterSelect: [
    "Filter type",
    "Tipo de filtro",
    "Choose which frequencies the synthesizer filter removes.",
    "Elige qué frecuencias elimina el filtro del sintetizador.",
  ],
  arpEnabled: [
    "Arpeggiator",
    "Arpegiador",
    "Turn held notes into a rhythmic sequence.",
    "Convierte las notas mantenidas en una secuencia rítmica.",
  ],
  arpMode: [
    "Arpeggio direction",
    "Dirección del arpegio",
    "Choose the order in which held notes are played.",
    "Elige el orden en el que se reproducen las notas.",
  ],
  arpOctaves: [
    "Arpeggio octaves",
    "Octavas del arpegio",
    "Set the pitch range covered by the arpeggiator.",
    "Ajusta el rango tonal recorrido por el arpegiador.",
  ],
  arpRate: [
    "Arpeggio rate",
    "Velocidad del arpegio",
    "Choose the rhythmic subdivision for generated notes.",
    "Elige la subdivisión rítmica de las notas generadas.",
  ],
  lfoEnabled: [
    "LFO modulation",
    "Modulación LFO",
    "Enable cyclic movement for the selected target.",
    "Activa movimiento cíclico sobre el destino seleccionado.",
  ],
  lfoTarget: [
    "LFO target",
    "Destino del LFO",
    "Choose the sound parameter moved by the LFO.",
    "Elige el parámetro de sonido que moverá el LFO.",
  ],
  lfoRate: [
    "LFO rate",
    "Velocidad del LFO",
    "Set how quickly the modulation cycle repeats.",
    "Ajusta la velocidad con que se repite la modulación.",
  ],
  lfoDepth: [
    "LFO depth",
    "Profundidad del LFO",
    "Set the amount of cyclic modulation.",
    "Ajusta la cantidad de modulación cíclica.",
  ],
  fxBypass: [
    "Effects bypass",
    "Omitir efectos",
    "Disable or restore all effects on the selected track.",
    "Desactiva o restaura todos los efectos de la pista.",
  ],
  clipSelect: [
    "Active clip",
    "Clip activo",
    "Choose which independent pattern is edited for this track.",
    "Elige qué patrón independiente se edita en esta pista.",
  ],
  renameClipBtn: [
    "Rename clip",
    "Renombrar clip",
    "Give the active clip a descriptive name.",
    "Asigna un nombre descriptivo al clip activo.",
  ],
  duplicateBtn: [
    "Duplicate clip",
    "Duplicar clip",
    "Create an independent copy of the active clip.",
    "Crea una copia independiente del clip activo.",
  ],
  mutateBtn: [
    "Mutate clip",
    "Mutar clip",
    "Generate a controlled variation using the Tension macro.",
    "Genera una variación controlada usando la macro Tensión.",
  ],
  backingBtn: [
    "Backing generator",
    "Generador de bases",
    "Create a structured accompaniment for bass, pad and drums without changing guitar or lead clips.",
    "Crea un acompañamiento estructurado de bajo, pad y batería sin cambiar los clips de guitarra ni lead.",
  ],
  generateBackingBtn: [
    "Generate backing",
    "Generar base",
    "Replace the arrangement with the selected generated backing. The edit can be undone.",
    "Reemplaza el arreglo por la base generada seleccionada. La edición se puede deshacer.",
  ],
  barsSelect: [
    "Clip length",
    "Duración del clip",
    "Resize the active clip in musical bars.",
    "Cambia la duración del clip activo en compases.",
  ],
  gridSelect: [
    "Snap grid",
    "Rejilla de ajuste",
    "Choose the rhythmic resolution for placing and moving notes.",
    "Elige la resolución rítmica para colocar y mover notas.",
  ],
  zoomRange: [
    "Editor zoom",
    "Zoom del editor",
    "Change the horizontal width of sequencer steps.",
    "Cambia el ancho horizontal de los pasos del secuenciador.",
  ],
  keySelect: [
    "Song key",
    "Tonalidad",
    "Set the root note used by scale-aware generators.",
    "Ajusta la nota raíz usada por los generadores musicales.",
  ],
  scaleSelect: [
    "Musical scale",
    "Escala musical",
    "Constrain generated material to a harmonic scale.",
    "Limita el material generado a una escala armónica.",
  ],
  quantizeBtn: [
    "Quantize",
    "Cuantizar",
    "Align notes to the currently selected snap grid.",
    "Alinea las notas con la rejilla seleccionada.",
  ],
  automationParam: [
    "Automation lane",
    "Línea de automatización",
    "Choose which parameter is drawn below the piano roll.",
    "Elige qué parámetro se dibuja bajo el piano roll.",
  ],
  clearAutomationBtn: [
    "Clear automation",
    "Limpiar automatización",
    "Remove every point from the visible automation lane.",
    "Elimina todos los puntos de la automatización visible.",
  ],
  addSceneBtn: [
    "Add section",
    "Añadir sección",
    "Append a new song section using the active clips.",
    "Añade una nueva sección usando los clips activos.",
  ],
  autoArrangeBtn: [
    "Auto sequence",
    "Secuencia automática",
    "Distribute available clips across the complete song.",
    "Distribuye los clips disponibles a lo largo de la canción.",
  ],
  deleteClipBtn: [
    "Delete active clip",
    "Borrar clip activo",
    "Delete this clip safely. Arrangement sections are reassigned and the operation can be undone.",
    "Borra este clip de forma segura. Las secciones del arreglo se reasignan y puedes deshacer la operación.",
  ],
  confirmDeleteClipBtn: [
    "Confirm clip deletion",
    "Confirmar borrado del clip",
    "Permanently remove the selected clip from this project.",
    "Elimina el clip seleccionado de este proyecto.",
  ],
  sequencer: [
    "Piano roll",
    "Piano roll",
    "Click to add a note. Drag across empty space to select several notes; hold Shift to add them to the current selection.",
    "Haz clic para añadir una nota. Arrastra sobre un espacio vacío para seleccionar varias; mantén Mayús para sumarlas a la selección actual.",
  ],
};
Object.assign(controlDescriptions, {
  arpEnabled: [
    "Clip arpeggiator",
    "Arpegiador del clip",
    "Turn held notes in the active clip into a rhythmic sequence.",
    "Convierte las notas mantenidas del clip activo en una secuencia rítmica.",
  ],
  lfoEnabled: [
    "Clip LFO",
    "LFO del clip",
    "Enable cyclic modulation for the active clip.",
    "Activa la modulación cíclica del clip activo.",
  ],
  fxBypass: [
    "Clip effects bypass",
    "Omitir efectos del clip",
    "Disable or restore effects on the active clip.",
    "Desactiva o restaura los efectos del clip activo.",
  ],
  clipSelect: [
    "Active clip and character",
    "Clip y carácter activos",
    "Choose the pattern together with its independent motion, effects and vector settings.",
    "Elige el patrón junto con sus ajustes independientes de movimiento, efectos y vectores.",
  ],
});
Object.assign(controlDescriptions, {
  scratchCaptureBtn: [
    "Capture active mix",
    "Capturar mezcla activa",
    "Render the active clips into a mastered one, two, four, or eight-bar scratch buffer.",
    "Renderiza los clips activos en un búfer masterizado de uno, dos, cuatro u ocho compases.",
  ],
  scratchImport: [
    "Import audio to Scratch Deck",
    "Importar audio al plato",
    "Load a local WAV, MP3, OGG, or other browser-decodable audio file into the temporary Scratch Deck buffer.",
    "Carga un WAV, MP3, OGG u otro archivo decodificable por el navegador en el búfer temporal del plato.",
  ],
  scratchPlatter: [
    "Bidirectional scratch platter",
    "Plato de scratch bidireccional",
    "Drag in either direction for sample-accurate scratching. Release to return smoothly to normal motor speed.",
    "Arrastra en ambas direcciones para hacer scratch con precisión de muestra. Suelta para recuperar suavemente la velocidad normal.",
  ],
  scratchSyncBtn: [
    "Beat sync",
    "Sincronía de pulso",
    "Move the deck to the nearest beat boundary and return to normal speed.",
    "Mueve el plato al pulso más cercano y recupera la velocidad normal.",
  ],
  scratchBrakeBtn: [
    "Motor brake",
    "Freno de motor",
    "Slow the deck to a stop with a progressive motor brake.",
    "Detiene el plato progresivamente con un freno de motor.",
  ],
  scratchSpinBtn: [
    "Spinback",
    "Retroceso",
    "Throw the record backwards and let it decelerate.",
    "Lanza el disco hacia atrás y deja que desacelere.",
  ],
  scratchStutterBtn: [
    "Beat stutter",
    "Repetición rítmica",
    "Loop a short tempo-derived fragment until this control is released.",
    "Repite un fragmento corto derivado del tempo hasta desactivar el control.",
  ],
  scratchMix: [
    "Deck crossfader",
    "Crossfader del plato",
    "Blend between the live program and the captured Scratch Deck with equal-power curves.",
    "Mezcla el programa en directo y el plato capturado con curvas de potencia constante.",
  ],
  scratchFilter: [
    "Deck filter",
    "Filtro del plato",
    "Darken the Scratch Deck with a smooth resonant-free low-pass filter.",
    "Oscurece el plato con un filtro paso bajo suave y sin resonancia.",
  ],
  scratchWaveform: [
    "Scratch waveform",
    "Forma de onda de scratch",
    "Shows the captured buffer and its live playback position.",
    "Muestra el búfer capturado y su posición de reproducción en directo.",
  ],
});
Object.assign(controlDescriptions, {
  exportBtn: [
    "Export",
    "Exportar",
    "Repeat the last export recipe and update its linked file. Shortcut: Ctrl or Command plus E.",
    "Repite la última exportación y actualiza su archivo vinculado. Atajo: Ctrl o Comando más E.",
  ],
  exportAsBtn: [
    "Export As",
    "Exportar como",
    "Choose a format and always select a new destination. Shortcut: Ctrl or Command plus Shift plus E.",
    "Elige un formato y selecciona siempre un destino nuevo. Atajo: Ctrl o Comando más Mayús más E.",
  ],
  globalPosition: [
    "Song start locator",
    "Localizador de inicio de canción",
    "Choose the exact arrangement step where global playback begins.",
    "Elige el paso exacto del arreglo donde comienza la reproducción global.",
  ],
  clipPosition: [
    "Clip start locator",
    "Localizador de inicio del clip",
    "Choose the exact step where active-clip playback begins.",
    "Elige el paso exacto donde comienza la reproducción del clip activo.",
  ],
  performanceRecordBtn: [
    "Record performance take",
    "Grabar toma de interpretación",
    "Capture the audible master in real time, including the Scratch Deck.",
    "Captura el master audible en tiempo real, incluido el plato de scratch.",
  ],
});
function applyLanguage(render = false): any {
  return workflow.applyLanguage(runtime, render);
}
function controlInfo(el: any): [string, string] {
  return workflow.controlInfo(runtime, el);
}
function installControlHelp(): any {
  return workflow.installControlHelp(runtime);
}
function showHelpIntro(): any {
  return workflow.showHelpIntro(runtime);
}
function toggleHelp(force?: boolean): any {
  return workflow.toggleHelp(runtime, force);
}
function showControlHelp(el: any): any {
  return workflow.showControlHelp(runtime, el);
}
const tutorialSteps = () => [
  {
    target: ".transport",
    view: "forge",
    title: msg("ui_e9b43f615739"),
    body: msg("ui_037454240759"),
  },
  {
    target: ".track-rail",
    view: "forge",
    title: msg("ui_8147d7cb07cd"),
    body: msg("ui_ebdf07546c6d"),
  },
  {
    target: "#synthRack",
    view: "forge",
    title: msg("ui_f1bd34c2cdfc"),
    body: msg("ui_f1eee9c6d0aa"),
  },
  {
    target: ".piano-shell",
    view: "forge",
    title: msg("ui_fa450dfcc9d4"),
    body: msg("ui_0c72e968d7d3"),
  },
  {
    target: "#arrangeView .section-title",
    view: "arrange",
    title: msg("ui_3c5cfc67663d"),
    body: msg("ui_db7970e0e1d5"),
  },
  {
    target: "#performView .performance",
    view: "perform",
    title: msg("ui_0f34bb074d3d"),
    body: msg("ui_e888522d73e2"),
  },
  {
    target: ".modebar",
    view: "forge",
    title: msg("ui_77c41d35d999"),
    body: msg("ui_dd7c8962262e"),
  },
];
function showTutorialStep(): any {
  return workflow.showTutorialStep(runtime);
}
function startTutorial(): any {
  return workflow.startTutorial(runtime);
}
function endTutorial(): any {
  return workflow.endTutorial(runtime);
}
function initLearning(): any {
  return workflow.initLearning(runtime);
}

function renderTracks(): any {
  return instruments.renderTracks(runtime);
}
function renderInspector(): any {
  return instruments.renderInspector(runtime);
}
function applyPreset(track: TrackId, name: string): any {
  return instruments.applyPreset(runtime, track, name);
}
function renderArp(): any {
  return instruments.renderArp(runtime);
}
function renderFx(): any {
  return instruments.renderFx(runtime);
}
function macroMarkup(container: any): any {
  return instruments.macroMarkup(runtime, container);
}

function renderClipControls(): any {
  return instruments.renderClipControls(runtime);
}
function updateDeleteClipDialog(): any {
  return workflow.updateDeleteClipDialog(runtime);
}
function requestClipDelete(id: string): any {
  return workflow.requestClipDelete(runtime, id);
}
function renderHarmony(): any {
  return instruments.renderHarmony(runtime);
}

function renderPiano(): any {
  return performanceFeature.renderPiano(runtime);
}
function bindMarqueeSelection(seq: any): any {
  return performanceFeature.bindMarqueeSelection(runtime, seq);
}
function bindNoteDrag(
  el: any,
  c: any,
  rows: number[],
  zoom: number,
  rowH: number,
): any {
  return bindNoteGesture(runtime, el, c, rows, zoom, rowH);
}
function syncSelectedClasses(): any {
  return performanceFeature.syncSelectedClasses(runtime);
}
function syncRollScroll(): any {
  return performanceFeature.syncRollScroll(runtime);
}
function setDefaultScroll(): any {
  return performanceFeature.setDefaultScroll(runtime);
}

function renderSelection(): any {
  return performanceFeature.renderSelection(runtime);
}
function editSelection(key: any, value: any): any {
  return performanceFeature.editSelection(runtime, key, value);
}
function deleteSelection(): any {
  return performanceFeature.deleteSelection(runtime);
}

function renderAutomation(): any {
  return audio_studio.renderAutomation(runtime);
}

const heldKeyPointers = new Map<number, { source: string; key: HTMLElement }>();
function releaseKeyPointer(pointerId: number): any {
  return performanceFeature.releaseKeyPointer(runtime, pointerId);
}
function releaseKeyPointers(): any {
  return performanceFeature.releaseKeyPointers(runtime);
}
window.addEventListener(
  "pointerup",
  (event) => releaseKeyPointer(event.pointerId),
  true,
);
window.addEventListener(
  "pointercancel",
  (event) => releaseKeyPointer(event.pointerId),
  true,
);
window.addEventListener("blur", releaseKeyPointers);
document.addEventListener("visibilitychange", () => {
  if (document.hidden) releaseKeyPointers();
});
let instrumentOctave = 0;
function renderKeyboard(): any {
  return performanceFeature.renderKeyboard(runtime);
}
function startPerformance(
  source: string,
  pitch: number,
  velocity = 0.8,
  el: any = null,
  expression: Partial<NoteExpression> = {},
  channel: number | null = null,
): any {
  return performanceFeature.startPerformance(
    runtime,
    source,
    pitch,
    velocity,
    el,
    expression,
    channel,
  );
}
function endPerformance(source: string, el: any = null): any {
  return performanceFeature.endPerformance(runtime, source, el);
}

function launcherSnapshot(name = "LIVE"): any {
  return workflow.launcherSnapshot(runtime, name);
}
async function launchClip(track: TrackId, clipId: string): Promise<any> {
  return launcher.launchClip(runtime, track, clipId);
}
function renderLauncher(): any {
  return launcher.renderLauncher(runtime);
}
function setupLauncher(): any {
  return launcher.setupLauncher(runtime);
}

function renderArrangement(): any {
  return arrangement.renderArrangement(runtime);
}
function sceneLength(scene: any): any {
  return workflow.sceneLength(runtime, scene);
}
function focusScene(i: number): any {
  return arrangement.focusScene(runtime, i);
}
function updatePlayheads(): any {
  return performanceFeature.updatePlayheads(runtime);
}
function updatePosition(): any {
  return performanceFeature.updatePosition(runtime);
}
function updateOrb(): any {
  return instruments.updateOrb(runtime);
}

function songLength(): any {
  return workflow.songLength(runtime);
}
function formatLocator(step: number): any {
  return instruments.formatLocator(runtime, step);
}
function setGlobalStart(value: number): any {
  return workflow.setGlobalStart(runtime, value);
}
function setClipStart(value: number, seek = true): any {
  return workflow.setClipStart(runtime, value, seek);
}
function renderLocators(): any {
  return performanceFeature.renderLocators(runtime);
}
function syncLocatorsFromPlayback(): any {
  return performanceFeature.syncLocatorsFromPlayback(runtime);
}

function renderMixer(): any {
  return mixer.renderMixer(runtime);
}
function animateMixer(): any {
  return mixer.animateMixer(runtime);
}

function updateScratchPlayButton(): any {
  return scratch.updateScratchPlayButton(runtime);
}
async function armScratchBuffer(
  buffer: AudioBuffer,
  label: string,
): Promise<any> {
  return scratch.armScratchBuffer(runtime, buffer, label);
}
async function importScratchFile(file: File): Promise<any> {
  return scratch.importScratchFile(runtime, file);
}
async function audioRegionScratchBuffer(
  lane: AudioLane,
  region: AudioRegion,
): Promise<any> {
  return scratch.audioRegionScratchBuffer(runtime, lane, region);
}
async function loadAudioRegionIntoScratch(
  lane: AudioLane,
  region: AudioRegion,
  button: HTMLButtonElement,
): Promise<any> {
  return scratch.loadAudioRegionIntoScratch(runtime, lane, region, button);
}
async function captureScratchMix(): Promise<any> {
  return scratch.captureScratchMix(runtime);
}
function animateScratchDeck(now = performance.now()): any {
  return scratch.animateScratchDeck(runtime, now);
}

function setupScratchDeck(): any {
  return scratch.setupScratchDeck(runtime);
}

const performanceEventThrottle = new Map<string, number>();
function performanceStep(): any {
  return workflow.performanceStep(runtime);
}
function recordPerformanceEvent(
  kind: PerformanceEvent["kind"],
  target: string,
  value: number | string | boolean,
): any {
  return performanceFeature.recordPerformanceEvent(
    runtime,
    kind,
    target,
    value,
  );
}
async function loadPerformanceAudio(take: PerformanceTake): Promise<any> {
  return performanceFeature.loadPerformanceAudio(runtime, take);
}
function applyPerformanceEvent(event: PerformanceEvent): any {
  return performanceFeature.applyPerformanceEvent(runtime, event);
}
async function playPerformanceTake(take: PerformanceTake): Promise<any> {
  return performanceFeature.playPerformanceTake(runtime, take);
}
function openTakeEditor(take: PerformanceTake): any {
  return workflow.openTakeEditor(runtime, take);
}
function renderPerformanceTakes(): any {
  return performanceFeature.renderPerformanceTakes(runtime);
}
async function togglePerformanceCapture(): Promise<any> {
  return performanceFeature.togglePerformanceCapture(runtime);
}
function mixSnapshot(): any {
  return workflow.mixSnapshot(runtime);
}
function captureMixerReference(): any {
  return mixer.captureMixerReference(runtime);
}
function toggleMixerReference(): any {
  return mixer.toggleMixerReference(runtime);
}
function setupArrangeTools(): any {
  return arrangement.setupArrangeTools(runtime);
}
type UserPreset = {
  id: string;
  name: string;
  track: TrackId;
  tags: string[];
  instrument: import("./model.js").InstrumentState;
  character: any;
};
const USER_PRESETS = "kiber-vengance-user-presets-v1",
  PRESET_FAVORITES = "kiber-vengance-preset-favorites-v1";
function userPresets(): UserPreset[] {
  return instruments.userPresets(runtime);
}
function saveUserPresets(items: UserPreset[]): any {
  return instruments.saveUserPresets(runtime, items);
}
function presetFavorites(): any {
  return workflow.presetFavorites(runtime);
}
function renderPresetLibrary(): any {
  return instruments.renderPresetLibrary(runtime);
}
function saveCurrentPreset(): any {
  return instruments.saveCurrentPreset(runtime);
}
async function loadLocalSample(asset: SampleAsset): Promise<any> {
  return instruments.loadLocalSample(runtime, asset);
}
async function loadLocalSamples(): Promise<any> {
  return instruments.loadLocalSamples(runtime);
}
function renderSampleSlots(): any {
  return instruments.renderSampleSlots(runtime);
}
function setupLibraries(): any {
  return workflow.setupLibraries(runtime);
}
function setupPrecisionControls(): any {
  return mixer.setupPrecisionControls(runtime);
}
function setupStudioExtensions(): any {
  return workflow.setupStudioExtensions(runtime);
}

type CommandAction = {
  label: string;
  labelEs: string;
  group: string;
  groupEs: string;
  shortcut: string;
  icon: string;
  keywords: string;
  run: () => void;
};
function readUiPrefs(): {
  focus: boolean;
  collapsed: string[];
  compact: boolean;
} {
  return workflow.readUiPrefs(runtime);
}
function writeUiPrefs(): any {
  return workflow.writeUiPrefs(runtime);
}
function setRackCollapsed(id: string, collapsed: boolean, persist = true): any {
  return workflow.setRackCollapsed(runtime, id, collapsed, persist);
}
function toggleFocus(force?: boolean, silent = false): any {
  return workflow.toggleFocus(runtime, force, silent);
}
function selectTrack(track: TrackId): any {
  return workflow.selectTrack(runtime, track);
}
const commands: CommandAction[] = [
  {
    label: "Play / stop transport",
    labelEs: "Reproducir / detener transporte",
    group: "TRANSPORT",
    groupEs: "TRANSPORTE",
    shortcut: "SPACE",
    icon: "▶",
    keywords: "play stop transport reproducir parar",
    run: () => togglePlay(),
  },
  {
    label: "Arm / disarm recording",
    labelEs: "Armar / desarmar grabación",
    group: "TRANSPORT",
    groupEs: "TRANSPORTE",
    shortcut: "R",
    icon: "●",
    keywords: "record arm grabar",
    run: () => $("#recordBtn").click(),
  },
  {
    label: "Toggle metronome",
    labelEs: "Activar metrónomo",
    group: "TRANSPORT",
    groupEs: "TRANSPORTE",
    shortcut: "",
    icon: "⌁",
    keywords: "metro click metrónomo",
    run: () => $("#metroBtn").click(),
  },
  {
    label: "Toggle Solo on active track",
    labelEs: "Activar o quitar Solo en la pista activa",
    group: "MIX",
    groupEs: "MEZCLA",
    shortcut: "SHIFT S",
    icon: "S",
    keywords:
      "solo isolate isolation aislar aislamiento restore mix mezcla instrument instrumento",
    run: () => $(`[data-solo="${selectedTrack}"]`)?.click(),
  },
  {
    label: "Toggle Mute on active track",
    labelEs: "Silenciar o restaurar la pista activa",
    group: "MIX",
    groupEs: "MEZCLA",
    shortcut: "SHIFT M",
    icon: "M",
    keywords:
      "mute silence silenciar restore restaurar mix mezcla instrument instrumento",
    run: () => $(`[data-mute="${selectedTrack}"]`)?.click(),
  },
  {
    label: "Open Forge",
    labelEs: "Abrir Forja",
    group: "VIEW",
    groupEs: "VISTA",
    shortcut: "SHIFT G",
    icon: "F",
    keywords: "forge forja editor piano",
    run: () => activateView("forge"),
  },
  {
    label: "Open Arrange",
    labelEs: "Abrir Arreglo",
    group: "VIEW",
    groupEs: "VISTA",
    shortcut: "SHIFT A",
    icon: "A",
    keywords: "arrange arreglo song scenes",
    run: () => activateView("arrange"),
  },
  {
    label: "Open Clip Launcher",
    labelEs: "Abrir Lanzador de clips",
    group: "VIEW",
    groupEs: "VISTA",
    shortcut: "SHIFT L",
    icon: "L",
    keywords: "launch launcher clips grid live lanzar matriz",
    run: () => activateView("launch"),
  },
  {
    label: "Open Mix Console",
    labelEs: "Abrir mesa de mezcla",
    group: "VIEW",
    groupEs: "VISTA",
    shortcut: "SHIFT X",
    icon: "X",
    keywords: "mix mixer mezcla console fader",
    run: () => activateView("mix"),
  },
  {
    label: "Open Perform",
    labelEs: "Abrir Interpretación",
    group: "VIEW",
    groupEs: "VISTA",
    shortcut: "SHIFT P",
    icon: "P",
    keywords: "perform interpretar live macros",
    run: () => activateView("perform"),
  },
  {
    label: "Toggle Focus mode",
    labelEs: "Activar modo Foco",
    group: "VIEW",
    groupEs: "VISTA",
    shortcut: "SHIFT F",
    icon: "⌖",
    keywords: "focus foco collapse fast editor",
    run: () => toggleFocus(),
  },
  {
    label: "New independent clip",
    labelEs: "Nuevo clip independiente",
    group: "CLIP",
    groupEs: "CLIP",
    shortcut: "SHIFT N",
    icon: "＋",
    keywords: "new nuevo clip create",
    run: () => $("#newClipBtn").click(),
  },
  {
    label: "Generate melody with local AI",
    labelEs: "Generar melodía con IA local",
    group: "CLIP",
    groupEs: "CLIP",
    shortcut: "",
    icon: "✦",
    keywords:
      "ai ia local prompt melody melodia melodía generar generador inteligencia artificial cpu gpu qwen smollm",
    run: () => studioBridge.openLocalAI(),
  },
  {
    label: "Duplicate active clip",
    labelEs: "Duplicar clip activo",
    group: "CLIP",
    groupEs: "CLIP",
    shortcut: "SHIFT D",
    icon: "⧉",
    keywords: "duplicate duplicar copy clip",
    run: () => $("#duplicateBtn").click(),
  },
  {
    label: "Delete active clip",
    labelEs: "Borrar clip activo",
    group: "CLIP",
    groupEs: "CLIP",
    shortcut: "",
    icon: "⌫",
    keywords: "delete remove borrar eliminar clip",
    run: () => $("#deleteClipBtn").click(),
  },
  {
    label: "Mutate active clip",
    labelEs: "Mutar clip activo",
    group: "CLIP",
    groupEs: "CLIP",
    shortcut: "SHIFT V",
    icon: "⌁",
    keywords: "mutate mutar variation clip",
    run: () => $("#mutateBtn").click(),
  },
  {
    label: "Quantize active clip",
    labelEs: "Cuantizar clip activo",
    group: "CLIP",
    groupEs: "CLIP",
    shortcut: "SHIFT Q",
    icon: "▦",
    keywords: "quantize cuantizar snap notes",
    run: () => $("#quantizeBtn").click(),
  },
  {
    label: "Add arrangement section",
    labelEs: "Añadir sección al arreglo",
    group: "SONG",
    groupEs: "CANCIÓN",
    shortcut: "",
    icon: "＋",
    keywords: "section sección scene arrangement arreglo",
    run: () => {
      activateView("arrange");
      $("#addSceneBtn").click();
    },
  },
  {
    label: "Export to current destination",
    labelEs: "Exportar al destino actual",
    group: "PROJECT",
    groupEs: "PROYECTO",
    shortcut: "CTRL E",
    icon: "⇧",
    keywords: "export save current destino actual wav midi",
    run: repeatLastExport,
  },
  {
    label: "Export As…",
    labelEs: "Exportar como…",
    group: "PROJECT",
    groupEs: "PROYECTO",
    shortcut: "CTRL SHIFT E",
    icon: "…",
    keywords: "export as save choose elegir formato destino",
    run: () => open("#exportDialog"),
  },
  {
    label: "Export song WAV",
    labelEs: "Exportar canción WAV",
    group: "PROJECT",
    groupEs: "PROYECTO",
    shortcut: "",
    icon: "W",
    keywords: "export wav render audio canción",
    run: () => quickExportWav(false),
  },
  {
    label: "Export song MIDI",
    labelEs: "Exportar canción MIDI",
    group: "PROJECT",
    groupEs: "PROYECTO",
    shortcut: "",
    icon: "M",
    keywords: "export midi canción",
    run: () => quickExportMidi(false),
  },
  {
    label: "Export project as JSON",
    labelEs: "Exportar proyecto como JSON",
    group: "PROJECT",
    groupEs: "PROYECTO",
    shortcut: "",
    icon: "J",
    keywords: "export project json backup proyecto copia",
    run: () => quickExportProject(true),
  },
  {
    label: "Project, versions & recovery",
    labelEs: "Proyecto, versiones y recuperación",
    group: "PROJECT",
    groupEs: "PROYECTO",
    shortcut: "",
    icon: "••",
    keywords: "project proyecto save import snapshot",
    run: () => $("#menuBtn").click(),
  },
  ...projectTrackIds(project).map((track, index) => ({
    label: `Select ${trackMeta(project, track).label}`,
    labelEs: `Seleccionar ${trackMeta(project, track).label}`,
    group: "TRACK",
    groupEs: "PISTA",
    shortcut: String(index + 1),
    icon: String(index + 1),
    keywords: `track pista ${track} instrument instrumento`,
    run: () => selectTrack(track),
  })),
];
function matchingCommands(query: string): any {
  return workflow.matchingCommands(runtime, query);
}
function renderCommands(query = ""): any {
  return workflow.renderCommands(runtime, query);
}
function runCommand(command: CommandAction | undefined): any {
  return workflow.runCommand(runtime, command);
}
function openCommands(): any {
  return workflow.openCommands(runtime);
}
function initWorkflowUi(): any {
  return workflow.initWorkflowUi(runtime);
}

function renderVersions(): any {
  return storage.renderVersions(runtime);
}
function loadVersions(): any {
  return storage.loadVersions(runtime);
}
function saveVersion(): any {
  return storage.saveVersion(runtime);
}

let inputRecorder: MediaRecorder | null = null,
  inputStream: MediaStream | null = null,
  inputChunks: Blob[] = [],
  midiLearnTarget: string | null = null;
function applyMidiMapping(mapping: MidiMapping, normalized: number): any {
  return performanceFeature.applyMidiMapping(runtime, mapping, normalized);
}
function audioBufferWav(buffer: AudioBuffer): any {
  return workflow.audioBufferWav(runtime, buffer);
}
async function addAudioBlob(
  blob: Blob,
  name = "",
  lane?: AudioLane,
): Promise<any> {
  return audio_studio.addAudioBlob(runtime, blob, name, lane);
}
async function loadAudioAssets(): Promise<any> {
  return storage.loadAudioAssets(runtime);
}
function renderAudioStudio(): any {
  return audio_studio.renderAudioStudio(runtime);
}
function renderGlobalAutomation(): any {
  return audio_studio.renderGlobalAutomation(runtime);
}
function renderMixGroups(): any {
  return mixer.renderMixGroups(runtime);
}
function renderTempoMap(): any {
  return arrangement.renderTempoMap(runtime);
}
function samplerSettings(): SamplerInstrument {
  return sampler.samplerSettings(runtime);
}
function setupSamplerOctaveControls(): any {
  return sampler.setupSamplerOctaveControls(runtime);
}
function samplerNoteName(pitch: number): any {
  return sampler.samplerNoteName(runtime, pitch);
}
function drawSamplerWaveform(): any {
  return sampler.drawSamplerWaveform(runtime);
}
function startSamplerPerformance(
  source: string,
  pitch: number,
  velocity = 0.85,
  element?: HTMLElement | null,
): any {
  return sampler.startSamplerPerformance(
    runtime,
    source,
    pitch,
    velocity,
    element,
  );
}
function endSamplerPerformance(
  source: string,
  element?: HTMLElement | null,
): any {
  return sampler.endSamplerPerformance(runtime, source, element);
}
function renderSamplerKeyboard(): any {
  return sampler.renderSamplerKeyboard(runtime);
}
async function loadSamplerAsset(): Promise<any> {
  return sampler.loadSamplerAsset(runtime);
}
function setupSamplerKeyboard(): any {
  return sampler.setupSamplerKeyboard(runtime);
}
function setupV6Studio(): any {
  return audio_studio.setupV6Studio(runtime);
}
function setupMidiLearnUi(): any {
  return performanceFeature.setupMidiLearnUi(runtime);
}
function setupV6Copy(): any {
  return audio_studio.setupV6Copy(runtime);
}
function setupV6Safety(): any {
  return audio_studio.setupV6Safety(runtime);
}
function setupSampleSlicing(): any {
  return instruments.setupSampleSlicing(runtime);
}
function setupProjectTemplates(): any {
  return workflow.setupProjectTemplates(runtime);
}
function renderAll() {
  if (!project.tracks[selectedTrack]) {
    selectedTrack = projectTrackIds(project)[0]!;
    selectedNotes.clear();
  }
  renderTracks();
  renderClipControls();
  renderHarmony();
  renderLocators();
  if (soundPanel) {
    renderInspector();
    renderArp();
    renderFx();
    macroMarkup($("#macros"));
  }
  if (activeView === "forge") {
    renderPiano();
    renderAutomation();
    renderKeyboard();
  }
  if (activeView === "launch") renderLauncher();
  if (activeView === "arrange") {
    renderArrangement();
    renderTempoMap();
  }
  if (activeView === "mix") {
    renderMixer();
    renderMixGroups();
  }
  if (activeView === "audio") {
    renderAudioStudio();
    renderSamplerKeyboard();
  }
  if (activeView === "perform") {
    renderKeyboard();
    macroMarkup($("#performMacros"));
    renderPerformanceTakes();
  }
  $("#title").value = project.title;
  $("#tempo").value = project.tempo;
  $("#meterSelect").value = `${project.meter.beats}/${project.meter.unit}`;
  $("#recordMode").value = project.editor.recordMode || "quantized";
  $("#swing").value = Math.round(project.swing * 100);
  $("#masterVolume").value = project.master;
  $("#masterValue").textContent = formatDb(levelDb(project.master));
  updateOrb();
  installControlHelp();
  syncStudioUi();
}
function syncTransportButtons(running = engine.playing): any {
  return workflow.syncTransportButtons(runtime, running);
}
function pausePlayback(): any {
  return performanceFeature.pausePlayback(runtime);
}
async function togglePlay(forceSong?: boolean): Promise<any> {
  return performanceFeature.togglePlay(runtime, forceSong);
}
function animateMeter(): any {
  return performanceFeature.animateMeter(runtime);
}
function wavOptions(): any {
  return workflow.wavOptions(runtime);
}
function setExportProgress(value: number, status?: string): any {
  return storage.setExportProgress(runtime, value, status);
}
async function exportWav(
  song: boolean,
  target?: QuickTarget,
  format: "wav" | "ogg" = "wav",
): Promise<any> {
  return storage.exportWav(runtime, song, target, format);
}
function crc32(bytes: Uint8Array): any {
  return storage.crc32(runtime, bytes);
}
async function zipFiles(
  files: Array<{ name: string; data: Blob }>,
): Promise<any> {
  return storage.zipFiles(runtime, files);
}
async function readStoreZip(blob: Blob): Promise<any> {
  return storage.readStoreZip(runtime, blob);
}
async function importProjectFile(file: File): Promise<any> {
  return storage.importProjectFile(runtime, file);
}
async function renderStems(): Promise<any> {
  return workflow.renderStems(runtime);
}
async function renderProjectBundle(): Promise<any> {
  return workflow.renderProjectBundle(runtime);
}
const exportMeta: Record<
  QuickExportKind,
  { extension: string; type: string; description: string }
> = {
  ogg: {
    extension: ".ogg",
    type: "audio/ogg",
    description: "Ogg Vorbis audio",
  },
  wav: { extension: ".wav", type: "audio/wav", description: "Wave audio" },
  midi: { extension: ".mid", type: "audio/midi", description: "MIDI song" },
  project: {
    extension: ".json",
    type: "application/json",
    description: "КИБЕР VENGANCE project",
  },
  "clip-wav": {
    extension: ".wav",
    type: "audio/wav",
    description: "Wave audio",
  },
  "clip-midi": {
    extension: ".mid",
    type: "audio/midi",
    description: "MIDI clips",
  },
  stems: {
    extension: ".zip",
    type: "application/zip",
    description: "КИБЕР VENGANCE stems",
  },
  bundle: {
    extension: ".zip",
    type: "application/zip",
    description: "КИБЕР VENGANCE project package",
  },
  performance: {
    extension: ".webm",
    type: "audio/webm",
    description: "Live performance",
  },
};
function exportName(kind: QuickExportKind): any {
  return storage.exportName(runtime, kind);
}
async function performExport(
  kind: QuickExportKind,
  forcePicker = false,
): Promise<any> {
  return storage.performExport(runtime, kind, forcePicker);
}
async function quickExportWav(forcePicker = false): Promise<any> {
  return storage.quickExportWav(runtime, forcePicker);
}
async function quickExportMidi(forcePicker = false): Promise<any> {
  return storage.quickExportMidi(runtime, forcePicker);
}
function repeatLastExport(): any {
  return storage.repeatLastExport(runtime);
}

$("#playBtn").onclick = () => togglePlay();
$("#pauseBtn").onclick = pausePlayback;
$("#rewindBtn").onclick = () => {
  engine.stop();
  currentStep = -1;
  currentScene = -1;
  transportPosition = 0;
  setGlobalStart(0);
  setClipStart(0);
  updatePlayheads();
  syncTransportButtons(false);
  $("#pauseBtn").classList.remove("active");
};
$("#recordBtn").onclick = () => {
  recordArmed = !recordArmed;
  $("#recordBtn").classList.toggle("active", recordArmed);
  toast(
    recordArmed
      ? `RECORD ARMED · ${$("#countIn").value} BAR COUNT-IN`
      : "RECORD SAFE",
  );
  syncStudioUi();
};
$("#metroBtn").onclick = () => {
  metronome = !metronome;
  engine.metronome = metronome;
  $("#metroBtn").setAttribute("aria-pressed", metronome);
};
$("#tempo").onchange = () => {
  snapshot();
  project.tempo = Math.max(50, Math.min(220, +$("#tempo").value));
  const initialTempo = project.tempoMap.find((event: any) => event.step === 0);
  if (initialTempo) initialTempo.bpm = project.tempo;
  else
    project.tempoMap.unshift({
      id: cryptoId(),
      step: 0,
      bpm: project.tempo,
      curve: "jump",
    });
  changed();
};
$("#meterSelect").onchange = () => {
  snapshot();
  const [beats, unit] = $("#meterSelect").value.split("/").map(Number);
  setProjectMeter(project, beats, unit);
  selectedNotes.clear();
  changed(true);
};
$("#recordMode").onchange = () => {
  snapshot();
  project.editor.recordMode = $("#recordMode").value;
  changed();
  toast(
    project.editor.recordMode === "free"
      ? "FREE MICROTIMING RECORDING"
      : "QUANTIZED RECORDING",
  );
};
$("#swing").onchange = () => {
  snapshot();
  project.swing = Math.max(0, Math.min(0.6, +$("#swing").value / 100));
  changed();
};
$("#title").onchange = () => {
  snapshot();
  project.title = $("#title").value.trim() || "Untitled Signal";
  changed();
};
$("#masterVolume").onpointerdown = snapshot;
$("#masterVolume").oninput = () => {
  project.master = +$("#masterVolume").value;
  $("#masterValue").textContent = formatDb(levelDb(project.master));
  $("#mixerMaster").value = project.master;
  $("#mixerMasterValue").textContent = `${formatDb(levelDb(project.master))}%`;
  engine.setProject(project);
};
$("#masterVolume").onchange = () => changed();
$("#undoBtn").onclick = () => {
  releaseAllKeyboards();
  project = history.undo(project);
  void loadLocalSamples();
  void loadAudioAssets();
  engine.project = project;
  selectedNotes.clear();
  changed(true);
};
$("#redoBtn").onclick = () => {
  releaseAllKeyboards();
  project = history.redo(project);
  void loadLocalSamples();
  void loadAudioAssets();
  engine.project = project;
  selectedNotes.clear();
  changed(true);
};
$("#newClipBtn").onclick = () => {
  snapshot();
  const source = clip(),
    c = createClip(
      selectedTrack,
      `${trackMeta(project, selectedTrack).label} ${clipsForTrack(project, selectedTrack).length + 1}`,
      2,
      meterSteps(project.meter),
    );
  c.character = structuredClone(source.character);
  c.instrument = structuredClone(source.instrument);
  project.clips.push(c);
  project.activeClipIds[selectedTrack] = c.id;
  selectedNotes.clear();
  changed(true);
  toast(msg("ui_5c0b75942c31"), true);
};
$("#duplicateBtn").onclick = () => {
  snapshot();
  duplicateClip(project, clip().id);
  selectedNotes.clear();
  changed(true);
  toast(msg("ui_5872d1663485"), true);
};
$("#mutateBtn").onclick = () => {
  snapshot();
  varyClip(project, clip(), clip().character.macros.tension);
  selectedNotes.clear();
  changed(true);
  toast(msg("ui_350b42aa6d46"), true);
};
$("#noteLength").onchange = () =>
  editSelection("length", $("#noteLength").value);
$("#noteVelocity").onpointerdown = () => {
  if (selectedNotes.size) snapshot();
};
$("#noteVelocity").oninput = () => {
  for (const n of clip().notes.filter((n) => selectedNotes.has(n.id)))
    n.velocity = +$("#noteVelocity").value;
  renderPiano();
};
$("#noteVelocity").onchange = () => changed();
$("#deleteNotesBtn").onclick = deleteSelection;
$("#automationParam").onchange = () => {
  project.editor.automationParam = $("#automationParam").value;
  changed();
  renderAutomation();
};
$("#clearAutomationBtn").onclick = () => {
  snapshot();
  (clip().automation as any)[project.editor.automationParam] = {};
  changed();
  renderAutomation();
  toast(msg("ui_714477b33131"), true);
};
$("#addSceneBtn").onclick = () => {
  snapshot();
  addArrangementScene(project);
  changed(true);
  focusScene(project.arrangement.length - 1);
};
$("#autoArrangeBtn").onclick = () => {
  snapshot();
  distributeArrangementPatterns(project);
  changed(true);
  toast("CLIPS DISTRIBUTED ACROSS SONG");
};
function activateView(view: string) {
  if (!["forge", "arrange", "audio", "launch", "perform", "mix"].includes(view))
    return;
  releaseAllKeyboards();
  activeView = view;
  $$("[data-view]").forEach((x) =>
    x.classList.toggle("active", x.dataset.view === view),
  );
  $$(".view").forEach((v) =>
    v.classList.toggle("active", v.id === `${view}View`),
  );
  if (!engine.playing)
    engine.songMode = ["audio", "arrange", "mix"].includes(view);
  if (view === "forge") {
    renderPiano();
    renderAutomation();
    renderKeyboard();
    renderClipControls();
  }
  if (view === "launch") renderLauncher();
  if (view === "audio") {
    renderAudioStudio();
    renderSamplerKeyboard();
  }
  if (view === "arrange") {
    renderArrangement();
    renderTempoMap();
  }
  if (view === "mix") {
    renderMixer();
    renderMixGroups();
    requestAnimationFrame(animateMixer);
  }
  if (view === "perform") {
    renderKeyboard();
    macroMarkup($("#performMacros"));
    renderPerformanceTakes();
    animateScratchDeck();
  }
  syncStudioUi();
}
$$("[data-view]").forEach(
  (b: any) => (b.onclick = () => activateView(b.dataset.view)),
);
function compatibility(): any {
  return workflow.compatibility(runtime);
}
function showCompatibility(): any {
  return workflow.showCompatibility(runtime);
}
const open = (id: string) => $(id).showModal(),
  replaceProject = (next: Project) => {
    snapshot();
    project = next;
    engine.project = project;
    selectedNotes.clear();
    globalStartStep = 0;
    clipStartSteps.clear();
    changed(true);
    $("#projectMenu").close();
  };
$("#importScoreBtn").onclick = async () => {
  try {
    const { openScoreImport } = await import("./score/ui");
    openScoreImport({
      getAsset,
      putAsset,
      sources: () => project.scoreSources || [],
      notify: (message) => toast(message, true),
      async insert(document, file) {
        const [{ insertScore }, { scoreMusicXml }] = await Promise.all([
          import("./score/insert"),
          import("./score/musicxml"),
        ]);
        const id = crypto.randomUUID(),
          assetId = `score-source-${id}`,
          reviewAssetId = `score-review-${id}`,
          musicXmlAssetId = `score-xml-${id}`;
        await putAsset(assetId, file);
        await putAsset(
          reviewAssetId,
          new Blob([JSON.stringify(document)], { type: "application/json" }),
        );
        await putAsset(
          musicXmlAssetId,
          new Blob([scoreMusicXml(document)], {
            type: "application/vnd.recordare.musicxml+xml",
          }),
        );
        const next = structuredClone(project);
        const tracks = insertScore(next, document, {
          id,
          assetId,
          reviewAssetId,
          musicXmlAssetId,
          name: file.name,
          mimeType: file.type,
          format: document.format,
          partTracks: [],
        });
        snapshot();
        engine.stop();
        releaseAllKeyboards();
        project = next;
        selectedTrack = tracks[0] || "lead";
        selectedNotes.clear();
        history.finish(project);
        changed(true);
        setDefaultScroll();
      },
    });
  } catch (error) {
    toast(error instanceof Error ? error.message : String(error));
  }
};
for (const [id, adding] of [
  ["newTrackBtn", true],
  ["manageTrackBtn", false],
] as const)
  $("#" + id).onclick = async () => {
    const { editInstrumentTrack } = await import("./features/track-management");
    try {
      const result = await editInstrumentTrack(project, selectedTrack, adding);
      if (!result) return;
      snapshot();
      engine.stop();
      releaseAllKeyboards();
      project = result.project;
      selectedTrack = result.selectedTrack;
      selectedNotes.clear();
      history.finish(project);
      changed(true);
      setDefaultScroll();
      toast(L("Track updated", "Pista actualizada"), true);
    } catch (error) {
      toast(error instanceof Error ? error.message : String(error));
    }
  };
$("#menuBtn").onclick = () => {
  renderVersions();
  renderExportTargets();
  open("#projectMenu");
  $("#projectMenu .project-menu-body").scrollTop = 0;
};
$("#exportBtn").onclick = repeatLastExport;
$("#exportAsBtn").onclick = () => open("#exportDialog");
$("#helpBtn").onclick = () => open("#helpDialog");
$("#aboutBtn").onclick = () => open("#aboutDialog");
$$("[data-close]").forEach(
  (b: any) => (b.onclick = () => b.closest("dialog").close()),
);
$("#newBtn").onclick = async () => {
  if (
    await requestConfirmation(
      L("New demo project", "Nuevo proyecto demo"),
      L(
        "Replace the current project? You can undo this action.",
        "¿Reemplazar el proyecto actual? Puedes deshacer esta acción.",
      ),
    )
  )
    replaceProject(createProject());
};
$("#emptyBtn").onclick = async () => {
  if (
    await requestConfirmation(
      L("New empty project", "Nuevo proyecto vacío"),
      L(
        "Replace the current project? You can undo this action.",
        "¿Reemplazar el proyecto actual? Puedes deshacer esta acción.",
      ),
    )
  )
    replaceProject(createEmptyProject());
};
$("#duplicateProjectBtn").onclick = () => {
  const copy = migrateProject(structuredClone(project));
  copy.id = crypto.randomUUID();
  copy.title = `${project.title} Copy`;
  replaceProject(copy);
  toast("PROJECT DUPLICATED");
};
$("#saveBtn").onclick = saveVersion;
$("#exportProjectBtn").onclick = () => performExport("project", true);
$("#compatBtn").onclick = () => {
  $("#projectMenu").close();
  showCompatibility();
};
$("#copyCompatBtn").onclick = async () => {
  const text = JSON.stringify(compatibility(), null, 2);
  try {
    await navigator.clipboard.writeText(text);
    toast("COMPATIBILITY REPORT COPIED");
  } catch {
    download(text, "kiber-vengance-compatibility.json", "application/json");
  }
};
$("#importProject").onchange = async (e: any) => {
  try {
    snapshot();
    project = await importProjectFile(e.target.files[0]);
    engine.project = project;
    await loadLocalSamples();
    await loadSamplerAsset();
    await loadAudioAssets();
    await storage.showMissingAssets(runtime);
    selectedNotes.clear();
    changed(true);
    $("#projectMenu").close();
    toast("PROJECT IMPORTED");
  } catch (err) {
    toast(`IMPORT ERROR: ${err instanceof Error ? err.message : String(err)}`);
  }
};
$("#backingBtn").onclick = () => open("#backingDialog");
$("#backingIntensity").oninput = () =>
  ($("#backingIntensityValue").textContent = Math.round(
    +$("#backingIntensity").value * 100,
  ));
$("#generateBackingBtn").onclick = () => {
  snapshot();
  generateBacking(project, {
    sections: +$("#backingSections").value,
    intensity: +$("#backingIntensity").value,
    style: $("#backingStyle").value,
  });
  selectedNotes.clear();
  changed(true);
  $("#backingDialog").close();
  activateView("arrange");
  toast(msg("ui_144560ac18a5"), true);
};
$("#deleteClipDialog").onclose = () => (pendingDeleteClipId = null);
$("#confirmDeleteClipBtn").onclick = () => {
  if (!pendingDeleteClipId) return;
  const target = project.clips.find((c: any) => c.id === pendingDeleteClipId);
  if (!target) return;
  const name = target.name;
  snapshot();
  if (!deleteClip(project, pendingDeleteClipId)) {
    toast(msg("ui_49594184d6c0"));
    return;
  }
  pendingDeleteClipId = null;
  selectedNotes.clear();
  $("#deleteClipDialog").close();
  changed(true);
  toast(msg("ui_dabefe4930a0", { arg0: name }), true);
};

document.addEventListener(
  "keydown",
  (e) => {
    const target = e.target as HTMLElement,
      typing = Boolean(
        target?.closest?.(
          'textarea,[contenteditable="true"],input:not([type]),input[type="text"],input[type="search"],input[type="number"],input[type="email"],input[type="password"],input[type="url"],input[type="tel"]',
        ),
      ),
      blocked = $$("dialog").some((dialog) => dialog.open) || typing,
      key =
        e.code === "KeyS" || e.key.toLowerCase() === "s"
          ? "solo"
          : e.code === "KeyM" || e.key.toLowerCase() === "m"
            ? "mute"
            : e.code === "KeyV" || e.key.toLowerCase() === "v"
              ? "mutate"
              : null;
    if (
      !blocked &&
      !e.ctrlKey &&
      !e.metaKey &&
      !e.altKey &&
      e.shiftKey &&
      key
    ) {
      e.preventDefault();
      e.stopImmediatePropagation();
      (key === "mutate"
        ? $("#mutateBtn")
        : $(`[data-${key}="${selectedTrack}"]`)
      )?.click();
    }
  },
  { capture: true },
);

document.addEventListener("keydown", (e) => {
  const mod = e.ctrlKey || e.metaKey;
  if (mod && e.key.toLowerCase() === "k") {
    e.preventDefault();
    openCommands();
    return;
  }
  if (mod && e.key.toLowerCase() === "e") {
    e.preventDefault();
    if (e.shiftKey) open("#exportDialog");
    else repeatLastExport();
    return;
  }
  if ($("#commandDialog").open) return;
  if (
    ["INPUT", "SELECT", "TEXTAREA"].includes((e.target as HTMLElement)?.tagName)
  )
    return;
  if (e.shiftKey && e.key.toLowerCase() === "f") {
    e.preventDefault();
    toggleFocus();
    return;
  }
  if (e.shiftKey && e.key.toLowerCase() === "g") {
    e.preventDefault();
    activateView("forge");
    return;
  }
  if (e.shiftKey && e.key.toLowerCase() === "a") {
    e.preventDefault();
    activateView("arrange");
    return;
  }
  if (e.shiftKey && e.key.toLowerCase() === "l") {
    e.preventDefault();
    activateView("launch");
    return;
  }
  if (e.shiftKey && e.key.toLowerCase() === "x") {
    e.preventDefault();
    activateView("mix");
    return;
  }
  if (e.shiftKey && e.key.toLowerCase() === "p") {
    e.preventDefault();
    activateView("perform");
    return;
  }
  if (e.shiftKey && e.key.toLowerCase() === "n") {
    e.preventDefault();
    $("#newClipBtn").click();
    return;
  }
  if (e.shiftKey && e.key.toLowerCase() === "d") {
    e.preventDefault();
    $("#duplicateBtn").click();
    return;
  }
  if (e.shiftKey && e.key.toLowerCase() === "v") {
    e.preventDefault();
    $("#mutateBtn").click();
    return;
  }
  if (e.shiftKey && e.key.toLowerCase() === "q") {
    e.preventDefault();
    $("#quantizeBtn").click();
    return;
  }
  if (e.key.toLowerCase() === "r" && !mod) {
    e.preventDefault();
    $("#recordBtn").click();
    return;
  }
  if (e.code === "Space") {
    e.preventDefault();
    togglePlay();
    return;
  }
  if (/^Digit[1-5]$/.test(e.code)) {
    selectedTrack = projectTrackIds(project)[+e.code.at(-1)! - 1] ?? "lead";
    selectedNotes.clear();
    renderAll();
    setDefaultScroll();
    return;
  }
  if (mod && e.key.toLowerCase() === "z") {
    e.preventDefault();
    releaseAllKeyboards();
    project = e.shiftKey ? history.redo(project) : history.undo(project);
    void loadLocalSamples();
    void loadAudioAssets();
    engine.project = project;
    selectedNotes.clear();
    changed(true);
    return;
  }
  if (mod && e.key.toLowerCase() === "a") {
    e.preventDefault();
    selectedNotes = new Set(clip().notes.map((n) => n.id));
    syncSelectedClasses();
    renderSelection();
    return;
  }
  if (mod && e.key.toLowerCase() === "c") {
    clipboard = clip()
      .notes.filter((n) => selectedNotes.has(n.id))
      .map((n) => structuredClone(n));
    toast(`${clipboard.length} NOTES COPIED`);
    return;
  }
  if (mod && e.key.toLowerCase() === "v" && clipboard.length) {
    e.preventDefault();
    snapshot();
    const min = Math.min(...clipboard.map((n) => n.step)),
      offset = Math.min(clipLengthSteps(clip()) - 1, min + 4) - min,
      newNotes = clipboard.map((n) => ({
        ...n,
        id: crypto.randomUUID(),
        step: Math.min(clipLengthSteps(clip()) - n.length, n.step + offset),
      }));
    clip().notes.push(...newNotes);
    selectedNotes = new Set(newNotes.map((n) => n.id));
    changed();
    renderPiano();
    return;
  }
  if (["Delete", "Backspace"].includes(e.key)) {
    e.preventDefault();
    deleteSelection();
    return;
  }
  if (selectedNotes.size && e.key.startsWith("Arrow")) {
    e.preventDefault();
    snapshot();
    const delta = e.shiftKey ? 4 : project.editor.snap;
    for (const n of clip().notes.filter((n) => selectedNotes.has(n.id))) {
      if (e.altKey && (e.key === "ArrowRight" || e.key === "ArrowLeft"))
        n.length = Math.max(
          project.editor.snap,
          Math.min(
            clipLengthSteps(clip()) - n.step,
            n.length + (e.key === "ArrowRight" ? delta : -delta),
          ),
        );
      else if (e.key === "ArrowRight" || e.key === "ArrowLeft")
        n.step = Math.max(
          0,
          Math.min(
            clipLengthSteps(clip()) - n.length,
            n.step + (e.key === "ArrowRight" ? delta : -delta),
          ),
        );
      else if (trackKind(project, selectedTrack) !== "drums")
        n.pitch = Math.max(
          trackMeta(project, selectedTrack).low,
          Math.min(
            trackMeta(project, selectedTrack).high,
            n.pitch + (e.key === "ArrowUp" ? 1 : -1),
          ),
        );
    }
    changed();
    renderPiano();
    return;
  }
  const source = e.key.toLowerCase(),
    activeKeyMap =
      trackKind(project, selectedTrack) === "drums" ? drumKeyMap : keyMap,
    i = activeKeyMap.indexOf(source);
  if (
    i >= 0 &&
    !e.repeat &&
    !e.shiftKey &&
    !e.ctrlKey &&
    !e.metaKey &&
    !e.altKey &&
    !recording.has(source)
  ) {
    const keyboardId =
        activeView === "perform" ? "performanceKeyboard" : "keyboard",
      key = $(`#${keyboardId} .key[data-source="${source}"]`);
    if (key) startPerformance(source, +key.dataset.pitch, 0.82, key);
  }
});
document.addEventListener("keyup", (e) => {
  const source = e.key.toLowerCase(),
    activeKeyMap =
      trackKind(project, selectedTrack) === "drums" ? drumKeyMap : keyMap,
    keyboardId = activeView === "perform" ? "performanceKeyboard" : "keyboard";
  if (activeKeyMap.includes(source))
    endPerformance(source, $(`#${keyboardId} .key[data-source="${source}"]`));
});
async function initMidi(): Promise<any> {
  return performanceFeature.initMidi(runtime);
}
setupSamplerKeyboard();
setupSamplerOctaveControls();
const query = new URLSearchParams(location.search);
loadQuickHandles();
initWorkflowUi();
initLearning();
setupScratchDeck();
setupStudioExtensions();
setupPrecisionControls();
setupArrangeTools();
setupLauncher();
setupLibraries();
setupV6Studio();
setupMidiLearnUi();
setupV6Safety();
setupV6Copy();
setupSampleSlicing();
setupProjectTemplates();
renderAll();
applyLanguage();
loadLocalSamples();
if (query.get("view")) activateView(query.get("view")!);
$("#app").hidden = false;
$("#boot")?.remove();
setDefaultScroll();
initMidi();
if ("serviceWorker" in navigator && !query.has("qa"))
  navigator.serviceWorker.register("./sw.js").catch(() => {});

function syncStudioUi() {
  workflow.syncClipTransportButton(runtime);
  if (!copyQueued) {
    copyQueued = true;
    queueMicrotask(() => {
      copyQueued = false;
      translateDOM();
    });
  }
  studioBridge.update({
    view: activeView as StudioView,
    language,
    context: trackMeta(project, selectedTrack).label,
    inspector: soundPanel,
    playing: Boolean(engine.playing),
    paused: studioBridge.getSnapshot().paused,
    songMode: Boolean(engine.songMode),
    armed: recordArmed,
  });
  const context = $("#clipContext");
  if (!context) return;
  const c = clip();
  context.textContent = `${trackMeta(project, selectedTrack).label} → ${c.name} · ${c.bars} ${msg("ui_5a599b482fc1")}`;
  document.body.classList.toggle("sound-panel", soundPanel);
  document.body.dataset.editorTool = editorTool;
  $$("[data-studio-tab]").forEach((b: any) => {
    const tab = b.dataset.studioTab;
    const active =
      tab === "sound"
        ? activeView === "forge" && soundPanel
        : tab === "clips"
          ? activeView === "forge" && !soundPanel
          : activeView === tab;
    b.setAttribute("aria-pressed", String(active));
  });
  $$("button[data-editor-tool]").forEach((b: any) =>
    b.setAttribute("aria-pressed", String(b.dataset.editorTool === editorTool)),
  );
  const hint = $("#recordHint");
  hint.textContent = recordArmed
    ? msg("ui_bef5cb5becd0")
    : msg("ui_401015e021e1");
}
function duplicateSelectedNotes(): any {
  return performanceFeature.duplicateSelectedNotes(runtime);
}
function quantizeSelectedNotes(): any {
  return performanceFeature.quantizeSelectedNotes(runtime);
}
function setupStudioUi(): any {
  return workflow.setupStudioUi(runtime);
}
setupStudioUi();

function setupConsistentControls(): any {
  return workflow.setupConsistentControls(runtime);
}
setupConsistentControls();
syncTransportButtons();

studioBridge.navigate = (view) => activateView(view);
studioBridge.melodyTarget = () =>
  trackKind(project, selectedTrack) === "drums"
    ? null
    : {
        projectId: project.id,
        clipId: clip().id,
        track: selectedTrack,
        key: project.key,
        scale: project.scale,
        stepsPerBar: meterSteps(project.meter),
        tempo: project.tempo,
        context: captureMusicalContext(project, selectedTrack),
      };
studioBridge.applyMelody = (target, name, bars, notes, options = {}) => {
  const generated = buildPresetClip(
    project,
    target,
    name,
    bars,
    notes,
    options,
  );
  snapshot();
  commitPresetClip(project, generated, options.tempo);
  selectedTrack = target.track;
  selectedNotes.clear();
  changed(true);
  activateView("forge");
  toast(
    translate(
      "AI melody added as a new clip",
      "Melodía IA añadida como clip nuevo",
    ),
    true,
  );
};
studioBridge.storeSoundPreset = (value) => {
  const preset = validateSoundPreset(value);
  saveUserPresets([...userPresets(), { ...preset, id: crypto.randomUUID() }]);
};
studioBridge.auditionMelody = (
  target,
  notes,
  onEnd,
  sound,
  options = { bars: 4, loop: false },
) => {
  let cancelled = false;
  let pending: typeof notes | null = null;
  let ending: ReturnType<typeof setTimeout> | undefined;
  const previewProject = structuredClone(project);
  const previewClip = buildPresetClip(
    previewProject,
    target,
    "Preview",
    options.bars,
    notes,
    sound ? { sound } : {},
  );
  previewProject.clips.push(previewClip);
  previewProject.activeClipIds[target.track] = previewClip.id;
  previewProject.tempo = target.tempo;
  previewProject.tempoMap = [
    { id: "preview-tempo", step: 0, bpm: target.tempo, curve: "jump" },
  ];
  previewProject.automationLanes = [];
  previewProject.modulationRoutes = [];
  for (const track of projectTrackIds(project)) {
    previewProject.tracks[track]!.mute = track !== target.track;
    previewProject.tracks[track]!.solo = false;
    const active = activeClip(previewProject, track);
    if (active !== previewClip) {
      active.bars = options.bars;
      active.stepsPerBar = target.stepsPerBar;
    }
  }
  const previewEngine = new AudioEngine();
  const total = options.bars * target.stepsPerBar;
  const stop = () => {
    cancelled = true;
    clearTimeout(ending);
    previewEngine.stop();
    if (previewEngine.ctx && previewEngine.ctx.state !== "closed")
      void previewEngine.ctx.close().catch(() => {});
  };
  previewEngine.onStep = (step, time) => {
    if (cancelled || step < 0 || step % total !== total - 1) return;
    if (options.loop) {
      if (pending) {
        previewClip.notes = pending;
        pending = null;
      }
    } else if (!ending) {
      ending = setTimeout(
        () => {
          stop();
          onEnd();
        },
        Math.max(
          0,
          (time - previewEngine.ctx.currentTime + 60 / target.tempo / 4) * 1000,
        ),
      );
    }
  };
  void previewEngine
    .init()
    .then(async () => {
      if (cancelled) {
        stop();
        return;
      }
      if (project.id !== target.projectId)
        throw new Error("The project changed.");
      await previewEngine.start(previewProject);
      if (cancelled) stop();
    })
    .catch((error) => {
      if (cancelled) return;
      stop();
      onEnd(String(error));
    });
  return {
    stop,
    replace: (next) => {
      pending = structuredClone(next);
    },
  };
};
studioBridge.toggleFocus = () => toggleFocus();
studioBridge.toggleInspector = () => {
  soundPanel = !soundPanel;
  if (soundPanel) {
    renderInspector();
    renderArp();
    renderFx();
    macroMarkup($("#macros"));
    installControlHelp();
  }
  syncStudioUi();
};
studioBridge.release = () => {
  releaseKeyPointers();
  releaseAllKeyboards();
  for (const key of keyMap) endPerformance(key);
  for (const source of samplerHeld.keys()) endSamplerPerformance(source);
};
window.addEventListener("blur", () => studioBridge.release());
document.addEventListener("visibilitychange", () => {
  if (document.hidden) studioBridge.release();
});

document.addEventListener("visibilitychange", () => {
  if (!document.hidden) {
    if (activeView === "perform") animateScratchDeck();
    if (activeView === "mix") animateMixer();
  }
});

window.addEventListener("pagehide", () => {
  void projectSession.flush();
  try {
    projectRepository.preservePending(project);
  } catch {
    autosaveRecoveryNotice = true;
  }
});
document.addEventListener("visibilitychange", () => {
  if (document.hidden) {
    void projectSession.flush();
    try {
      projectRepository.preservePending(project);
    } catch {
      autosaveRecoveryNotice = true;
    }
  }
});

void storage.showMissingAssets(runtime).catch((error) => toast(String(error)));

if (!voiceGenerationUnavailable(navigator)) {
  void Promise.all([import("./ui/local-voice"), import("./ui/desktop-vocals")])
    .then(([speech, singing]) => {
      speech.setupLocalVoice(runtime);
      singing.setupDesktopVocals(runtime);
    })
    .catch((error) => toast(String(error)));
}
setupOutputMix(runtime);

if (autosaveRecoveryNotice) {
  const warning = $("#saveWarning");
  warning.hidden = false;
  warning.textContent = autosaveRecoveryBlocked
    ? L(
        "Unreadable autosave preserved in its original key; automatic saving is blocked. Export JSON to keep new work.",
        "Autoguardado ilegible conservado en su clave original; guardado automático bloqueado. Exporta JSON para conservar el trabajo nuevo.",
      )
    : L(
        "An unreadable autosave was preserved before loading a recovery project.",
        "Se conservó el autoguardado ilegible antes de cargar un proyecto de recuperación.",
      );
}
