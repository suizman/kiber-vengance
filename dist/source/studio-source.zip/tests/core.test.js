import test from 'node:test';
import assert from 'node:assert/strict';
import {
  PROJECT_VERSION, renderAssets, mixAudible, masterValue, clipTrackState, projectSeconds, projectDuration, projectAssets, TRACKS, createProject, createEmptyProject, migrateProject, activeClip, clipsForTrack, createClip, meterSteps, setProjectMeter,
  makeNote, toggleNote, duplicateClip, deleteClip, varyClip, resizeClip, clipLengthSteps, quantizeClip, automationValue, notesAtStep,
  generateClip, generateBacking, sceneLengthSteps, playbackEvents, encodeMidi, addArrangementScene, duplicateArrangementScene,
  moveArrangementScene, removeArrangementScene, distributeArrangementPatterns, isInScale, createPerformanceTake,
  quantizePerformanceTake, captureLauncherScenes, duplicateArrangementSelection, removeArrangementSelection, dbToGain, gainToDb, History,
  createAudioLane, createAudioRegion, audioRegionRate, createAutomationLane, evaluateAutomationLane, detectTransientSlices, transformNotes, tempoAtStep
} from '../dist/core.js';
import { AudioEngine, wavBlob } from '../dist/audio.js';

test('v6 demo is a complete serializable hybrid song with studio workflow state', () => {
  const p=createProject();
  assert.equal(p.version,PROJECT_VERSION);
  assert.deepEqual(Object.keys(p.activeClipIds),TRACKS);
  assert.equal(p.clips.length,10);
  assert.ok(p.arrangement.every(s=>TRACKS.every(t=>s.clipIds[t])));
  assert.ok(playbackEvents(p,{song:true}).durationSteps>64);
  assert.equal(JSON.parse(JSON.stringify(p)).title,'Chrome Requiem');
  assert.ok(p.clips.every(c=>c.character?.arp&&c.character?.lfo&&c.character?.fx&&c.character?.macros));
  assert.ok(p.tracks.lead.color);assert.equal(p.tracks.lead.sendMode,'post');assert.deepEqual(p.performanceTakes,[]);assert.ok(p.loop.end>p.loop.start);
  assert.equal(p.sampler.assetId,null);assert.equal(p.sampler.rootNote,60);assert.equal(p.sampler.mode,'gate');assert.ok(p.sampler.polyphony>=8);
});

test('v6 audio, automation, tempo and transformation primitives remain deterministic',()=>{const project=createProject(),lane=createAudioLane('VOCALS'),region=createAudioRegion('asset-1','Take',8,16,2);region.warp=true;region.sourceBpm=120;region.pitch=12;lane.regions.push(region);project.audioLanes.push(lane);assert.equal(audioRegionRate(region,120),2);const automation=createAutomationLane('master.volume');automation.points=[{id:'a',step:0,value:0,curve:'smooth'},{id:'b',step:8,value:1,curve:'linear'}];assert.equal(evaluateAutomationLane(automation,4),.5);project.tempoMap=[{id:'t1',step:0,bpm:100,curve:'linear'},{id:'t2',step:16,bpm:140,curve:'jump'}];assert.equal(tempoAtStep(project,8),120);const samples=new Float32Array(2048);samples[512]=1;samples[1024]=1;samples[1536]=1;const slices=detectTransientSlices(samples,4);assert.equal(slices[0],0);assert.equal(slices.at(-1),1);const clip=createClip('lead','Transform',1);clip.notes=[makeNote(0,60,1),makeNote(4,64,1)];transformNotes(clip,'retrograde');assert.deepEqual(clip.notes.map(note=>note.step),[11,15]);const restored=migrateProject(JSON.parse(JSON.stringify(project)));assert.equal(restored.audioLanes[0].regions[0].assetId,'asset-1');assert.equal(restored.tempoMap.length,2)});

test('empty projects and musical meters retain a complete five-track structure', () => {
  const empty=createEmptyProject();assert.equal(empty.clips.length,5);assert.ok(empty.clips.every(c=>c.notes.length===0));assert.equal(empty.arrangement.length,1);
  const p=createProject(),before=activeClip(p,'lead').notes[1].step;setProjectMeter(p,3,4);assert.equal(meterSteps(p.meter),12);assert.ok(p.clips.every(c=>c.stepsPerBar===12));assert.equal(activeClip(p,'lead').notes[1].step,Math.round(before*.75*4)/4);
  const midi=encodeMidi(p);assert.ok([...midi].some((byte,index,all)=>byte===0xff&&all[index+1]===0x58&&all[index+3]===3&&all[index+4]===2));
});

test('legacy v2 patterns migrate into independent per-track clips', () => {
  const legacy={version:2,title:'Legacy Signal',tempo:118,macros:{energy:.4},tracks:{lead:{drive:.7}},patterns:[{id:'p1',name:'Old Pattern',bars:2,notes:{lead:[{step:0,pitch:60,length:2,velocity:.8}],bass:[],pad:[],drums:[]}}],activePatternId:'p1',arrangement:[{id:'s1',name:'INTRO',patternId:'p1',repeats:2}]};
  const p=migrateProject(legacy);
  assert.equal(p.version,7);
  assert.equal(p.clips.length,5);
  assert.equal(activeClip(p,'lead').notes[0].pitch,60);
  assert.equal(activeClip(p,'lead').character.fx.distortion,.7);
  assert.equal(activeClip(p,'lead').character.macros.energy,.4);
  assert.ok(TRACKS.every(t=>p.arrangement[0].clipIds[t]));
});

test('v3 track character migrates into every existing clip without losing its sound',()=>{
  const legacy=createProject();legacy.version=3;legacy.macros={energy:.21,darkness:.32,tension:.43,aggression:.54,space:.65,complexity:.76};legacy.tracks.lead.arp={enabled:true,mode:'down',octaves:3,rate:2};legacy.tracks.lead.lfo={enabled:true,target:'pitch',rate:7,depth:.4};legacy.tracks.lead.fx={bypass:false,distortion:.81,saturation:.7,chorus:.2,delay:.3,reverb:.4,tone:.5};legacy.clips.forEach(c=>delete c.character);
  const migrated=migrateProject(JSON.parse(JSON.stringify(legacy))),lead=clipsForTrack(migrated,'lead');assert.equal(migrated.version,7);assert.ok(lead.every(c=>c.character.arp.mode==='down'&&c.character.fx.distortion===.81&&c.character.macros.space===.65));assert.equal(migrated.macros,undefined);assert.equal(migrated.tracks.lead.fx,undefined);
});

test('v4 projects migrate to v7 without changing musical material',()=>{const old=createProject(),notes=playbackEvents(old,{song:true}).events.map(event=>[event.track,event.step,event.pitch,event.clipId]);old.version=4;delete old.markers;delete old.loop;delete old.launcher;delete old.performanceTakes;delete old.samples;delete old.masterSettings;delete old.editor.arrangeZoom;delete old.audioLanes;delete old.automationLanes;delete old.modulationRoutes;delete old.mixerGroups;delete old.tempoMap;delete old.meterMap;delete old.midiMappings;for(const track of TRACKS){delete old.tracks[track].preGainDb;delete old.tracks[track].sendMode;delete old.tracks[track].color}const migrated=migrateProject(JSON.parse(JSON.stringify(old)));assert.equal(migrated.version,7);assert.deepEqual(playbackEvents(migrated,{song:true}).events.map(event=>[event.track,event.step,event.pitch,event.clipId]),notes);assert.equal(migrated.tracks.lead.preGainDb,0);assert.ok(migrated.editor.arrangeZoom);assert.deepEqual(migrated.audioLanes,[]);assert.equal(migrated.masterSettings.targetLufs,-14)});

test('v5 studio metadata survives a portable JSON round trip',()=>{const p=createProject();p.markers.push({id:'marker-1',step:12.5,name:'DROP',color:'#ff3bd4'});p.loop={enabled:true,start:8,end:40,punch:true};p.launcher.quantization=4;p.masterSettings.bypass=true;p.samples.push({id:'sample-1',name:'impact.wav',slot:0,size:2048,type:'audio/wav',trimStart:.1,trimEnd:.8,tune:-3,attack:.01,release:.2,reverse:true});p.tracks.lead.preGainDb=2.5;p.tracks.lead.sendMode='pre';const restored=migrateProject(JSON.parse(JSON.stringify(p)));assert.deepEqual(restored.markers,p.markers);assert.deepEqual(restored.loop,p.loop);assert.equal(restored.launcher.quantization,4);assert.equal(restored.masterSettings.bypass,true);assert.deepEqual(restored.samples,p.samples);assert.equal(restored.tracks.lead.preGainDb,2.5);assert.equal(restored.tracks.lead.sendMode,'pre')});

test('performance takes, launcher capture and multi-scene editing are serializable',()=>{const p=createProject(),take=createPerformanceTake('Pressure Take',16,[{id:'e1',step:1.31,kind:'macro',target:'energy',value:.8},{id:'e2',step:8.76,kind:'scratch',target:'speed',value:-1.4}]);quantizePerformanceTake(take,1);assert.deepEqual(take.events.map(event=>event.step),[1,9]);p.performanceTakes.push(take);const before=p.arrangement.length,captured=captureLauncherScenes(p,[{name:'LIVE A',clipIds:{...p.activeClipIds}},{name:'LIVE B',clipIds:{...p.activeClipIds},repeats:2}]);assert.equal(captured.length,2);assert.equal(p.arrangement.length,before+2);const copies=duplicateArrangementSelection(p,[0,1]);assert.equal(copies.length,2);assert.ok(removeArrangementSelection(p,[0,1]));assert.equal(migrateProject(JSON.parse(JSON.stringify(p))).performanceTakes[0].events.length,2)});

test('mixer decibel conversion is stable across silence and unity',()=>{assert.equal(dbToGain(-60),0);assert.equal(dbToGain(0),1);assert.ok(Math.abs(gainToDb(dbToGain(-12))+12)<1e-9);assert.equal(gainToDb(0),-60)});

test('clip editing covers toggling, duplication, resizing and quantization', () => {
  const p=createProject(),c=activeClip(p,'lead'),before=c.notes.length;
  assert.equal(toggleNote(c,2,61,.9,2),true);
  assert.equal(c.notes.length,before+1);
  assert.equal(toggleNote(c,2,61),false);
  const copy=duplicateClip(p,c.id);assert.notEqual(copy.id,c.id);assert.equal(copy.track,'lead');
  copy.character.fx.delay=.99;assert.notEqual(c.character.fx.delay,.99);
  copy.notes.push(makeNote(31.7,70,8,.8));resizeClip(copy,2);quantizeClip(copy,1);
  assert.ok(copy.notes.every(n=>Number.isInteger(n.step)&&n.step+n.length<=32));
  const variation=varyClip(p,c,.8);assert.ok(variation.notes.length>c.notes.length);
});

test('clip deletion reassigns arrangement references and protects the last track clip',()=>{
  const p=createProject(),target=activeClip(p,'guitar'),replacement=clipsForTrack(p,'guitar').find(c=>c.id!==target.id);p.arrangement.forEach(scene=>scene.clipIds.guitar=target.id);const before=p.clips.length;
  assert.equal(deleteClip(p,target.id)?.id,replacement.id);assert.equal(p.clips.length,before-1);assert.equal(p.activeClipIds.guitar,replacement.id);assert.ok(p.arrangement.every(scene=>scene.clipIds.guitar===replacement.id));assert.equal(deleteClip(p,replacement.id),null);assert.equal(clipsForTrack(p,'guitar').length,1);
});

test('automation interpolates between editable points', () => {
  const c=createClip('lead','Automation',2);c.automation.cutoff={0:.2,8:.8,16:.4};
  assert.equal(automationValue(c,'cutoff',0),.2);
  assert.ok(Math.abs(automationValue(c,'cutoff',4)-.5)<.001);
  assert.equal(automationValue(c,'cutoff',20),.4);
});

test('free timing and expressive note data survive playback and MIDI export', () => {
  const p=createEmptyProject(),c=activeClip(p,'lead'),note=makeNote(4,64,1.375,.72,.183,{pressure:.91,timbre:.77,bend:1.25});c.notes.push(note);
  const event=playbackEvents(p,{song:false}).events.find(e=>e.track==='lead');assert.ok(Math.abs(event.step-4.183)<.0001);assert.equal(event.basePitch,64);assert.equal(event.pitch,65.25);assert.equal(event.expression.timbre,.77);
  const midi=encodeMidi(p,{song:false});assert.ok([...midi].some(byte=>(byte&0xf0)===0xe0));assert.ok([...midi].some(byte=>(byte&0xf0)===0xd0));assert.ok([...midi].some((byte,index,all)=>(byte&0xf0)===0xb0&&all[index+1]===74));
  const restored=migrateProject(JSON.parse(JSON.stringify(p))),restoredNote=activeClip(restored,'lead').notes[0];assert.equal(restoredNote.offset,.183);assert.equal(restoredNote.expression.bend,1.25);
});

test('every clip has an independent serializable character and saturation stage',()=>{const p=createProject(),first=p.clips[0],second=p.clips[1];assert.ok(p.clips.every(clip=>Number.isFinite(clip.character.fx.saturation)));first.character.macros.space=.99;assert.notEqual(second.character.macros.space,.99);const e=new AudioEngine(),curve=e.saturationCurve(.65);assert.equal(curve.length,256);assert.ok(curve[200]<1)});

test('harmonic helpers and generators stay in the selected scale', () => {
  const p=createProject(),c=createClip('lead','Generated',4);generateClip(p,c,'riff',.8);
  assert.ok(c.notes.length>8);
  assert.ok(c.notes.every(n=>isInScale(n.pitch,p.key,p.scale)));
  generateClip(p,c,'chords',.6);assert.ok(c.notes.some(n=>n.length===16));
  const drums=createClip('drums','Generated Beat',2);generateClip(p,drums,'drums',.8);assert.ok(drums.notes.some(n=>n.pitch===0));
});

test('backing generator builds structured accompaniment and preserves guitar material',()=>{
  const p=createProject(),guitarId=p.activeClipIds.guitar,guitarNotes=activeClip(p,'guitar').notes.length,before=p.clips.length,scenes=generateBacking(p,{sections:4,intensity:.8,style:'driving'});
  assert.equal(scenes.length,4);assert.equal(p.arrangement.length,4);assert.ok(p.clips.length>=before+12);assert.equal(p.activeClipIds.guitar,guitarId);assert.equal(activeClip(p,'guitar').notes.length,guitarNotes);assert.ok(scenes.every(scene=>['bass','pad','drums'].every(track=>p.clips.find(c=>c.id===scene.clipIds[track])?.notes.length)));
});

test('arpeggiator expands held chords deterministically', () => {
  const p=createProject(),c=createClip('lead','Chord',1);c.notes=[makeNote(0,60,16,.8),makeNote(0,64,16,.8),makeNote(0,67,16,.8)];p.clips.push(c);p.activeClipIds.lead=c.id;c.character.arp={enabled:true,mode:'updown',octaves:2,rate:1};
  const sequence=Array.from({length:8},(_,s)=>notesAtStep(p,c,'lead',s)[0].pitch);
  assert.deepEqual(sequence.slice(0,4),[60,64,67,72]);
  assert.equal(sequence.length,8);
});

test('full-song playback flattens scenes and loops independent clip lengths', () => {
  const p=createProject(),{events,durationSteps}=playbackEvents(p,{song:true}),expected=p.arrangement.reduce((sum,s)=>sum+sceneLengthSteps(p,s)*s.repeats,0);
  assert.equal(durationSteps,expected);
  assert.ok(events.some(e=>e.step>=64));
  assert.ok(TRACKS.every(t=>events.some(e=>e.track===t)));
  assert.ok(events.every(e=>e.clipId&&Number.isFinite(e.localStep)));
});

test('MIDI export is format 1 with tempo plus five musical tracks', () => {
  const midi=encodeMidi(createProject(),{song:true}),view=new DataView(midi.buffer,midi.byteOffset,midi.byteLength);
  assert.equal(new TextDecoder().decode(midi.slice(0,4)),'MThd');
  assert.equal(view.getUint16(8),1);
  assert.equal(view.getUint16(10),6);
  assert.ok(midi.length>500);
});

test('arrangement editing alternates and distributes clips per track', () => {
  const p=createProject(),before=p.arrangement.length,added=addArrangementScene(p);
  assert.equal(p.arrangement.length,before+1);assert.ok(TRACKS.every(t=>added.clipIds[t]));
  const dup=duplicateArrangementScene(p,p.arrangement.length-1);assert.ok(moveArrangementScene(p,p.arrangement.length-1,0));assert.equal(p.arrangement[0].id,dup.id);assert.ok(removeArrangementScene(p,0));
  p.arrangement.forEach(s=>TRACKS.forEach(t=>s.clipIds[t]=clipsForTrack(p,t)[0].id));assert.ok(distributeArrangementPatterns(p));assert.equal(p.arrangement[1].clipIds.lead,clipsForTrack(p,'lead')[1].id);
});

test('history preserves deep undo and redo states', () => {const h=new History(),a={clips:[{notes:[1]}]},b={clips:[{notes:[1,2]}]};h.push(a);assert.deepEqual(h.undo(b),a);assert.deepEqual(h.redo(a),b)});

test('scheduler drops stale time and survives a ten-minute controlled-clock soak', () => {
  const e=new AudioEngine();e.ctx={currentTime:0};e.project=createProject();e.playing=true;e.nextTime=0;e.scheduleMusicStep=()=>{};e.advanceTransport=()=>e.position++;e.click=()=>{};
  for(let second=0;second<600;second++){e.ctx.currentTime=second;e.schedule();assert.ok(e.nextTime>=second-.1);}
  e.ctx.currentTime=1000;e.nextTime=0;e.schedule();assert.ok(e.nextTime>=1000);assert.ok(e.position>0);
});

test('solo schedules only the isolated instrument',()=>{const p=createProject();p.tracks.guitar.solo=true;const heard=[];const e=new AudioEngine();e.ctx={currentTime:0};e.project=p;e.position=0;e.songMode=false;e.metronome=false;e.voice=track=>heard.push(track);e.drum=()=>heard.push('drums');e.scheduleMusicStep(0);assert.ok(heard.length>0);assert.deepEqual([...new Set(heard)],['guitar'])});

test('diagnostics keep the effects graph at exactly five persistent buses', () => {const e=new AudioEngine();e.buses={lead:{},guitar:{},bass:{},pad:{},drums:{}};assert.equal(e.diagnostics().effectBuses,5)});

test('metronome emits accented bar clicks while music is scheduled', () => {const p=createProject();TRACKS.forEach(t=>p.tracks[t].mute=true);const e=new AudioEngine();e.project=p;e.position=0;e.songMode=false;e.metronome=true;let accents=[];e.click=(_time,accent)=>accents.push(accent);e.scheduleMusicStep(0);e.position=4;e.scheduleMusicStep(.1);assert.deepEqual(accents,[true,false])});

test('transport seeks to exact clip and global arrangement positions',()=>{const p=createProject(),e=new AudioEngine();e.project=p;assert.equal(e.seek(9,false),9);const firstLength=sceneLengthSteps(p,p.arrangement[0]);assert.equal(e.seek(firstLength+5,true),firstLength+5);assert.ok(e.sceneIndex>0||e.sceneRepeat>0);assert.equal(e.sceneStep,5);assert.equal(e.seek(playbackEvents(p,{song:true}).durationSteps,true),0)});

test('resized clips play their full length independently of the arrangement loop', () => {
  const project = createEmptyProject(), clip = activeClip(project, 'lead');
  resizeClip(clip, 2);
  project.loop = { enabled: true, start: 8, end: 32, punch: false };
  const steps = [], voices = [], engine = new AudioEngine(step => steps.push(step));
  engine.project = project;
  engine.ctx = { currentTime: 0 };
  engine.updateEffectBus = () => {};
  engine.scheduleAudioRegions = () => {};
  engine.voice = track => voices.push([track, engine.position]);
  for (const other of project.clips) other.notes = [];
  clip.character.arp.enabled = false;
  for (let step = 0; step < 24; step++) { engine.scheduleMusicStep(step); engine.advanceTransport(); }
  resizeClip(clip, 8);
  clip.notes = [makeNote(112, 60, 1)];
  for (let step = 24; step <= 128; step++) { engine.scheduleMusicStep(step); engine.advanceTransport(); }
  assert.deepEqual(steps, Array.from({ length: 129 }, (_, step) => step));
  assert.equal(steps[127] % clipLengthSteps(clip), 127);
  assert.equal(steps[128] % clipLengthSteps(clip), 0);
  assert.deepEqual(voices, [['lead', 112]]);
  resizeClip(clip, 1);
  assert.equal(engine.seek(31, false) % clipLengthSteps(clip), 15);
  engine.songMode = true;
  engine.seek(31, true);
  engine.advanceTransport();
  assert.equal(engine.position, 8);
  assert.equal(engine.sceneStep, 8);
});

test('legacy instruments migrate into independent clips without copying mixer state', () => {
  for (const version of [3, 4, 5, 6]) {
    const legacy = createProject(); legacy.version = version;
    for (const clip of legacy.clips) delete clip.instrument;
    Object.assign(legacy.tracks.lead, { preset: 'Custom legacy', cutoff: 1234, release: 1.7, volume: .31, pan: -.4 });
    const project = migrateProject(legacy), [a, b] = clipsForTrack(project, 'lead');
    assert.equal(a.instrument.preset, 'Custom legacy');
    assert.equal(b.instrument.cutoff, 1234);
    assert.equal(a.instrument.release, 1.7);
    assert.equal(a.instrument.volume, undefined);
    assert.equal(project.tracks.lead.volume, .31);
    a.instrument.cutoff = 7777;
    assert.equal(b.instrument.cutoff, 1234);
    const restored = migrateProject(JSON.parse(JSON.stringify(project)));
    assert.equal(restored.clips.find(c => c.id === a.id).instrument.cutoff, 7777);
    assert.equal(restored.clips.find(c => c.id === b.id).instrument.cutoff, 1234);
    const copy = duplicateClip(project, a.id); copy.instrument.release = .2;
    assert.equal(a.instrument.release, 1.7);
  }
  const legacy = migrateProject({ version: 2, tracks: { lead: { preset: 'Old lead', cutoff: 2222 } }, patterns: [{ id: 'old', notes: {} }] });
  assert.equal(activeClip(legacy, 'lead').instrument.cutoff, 2222);
});

test('song scheduling and clip launches use each instrument and preserve voice snapshots', () => {
  const project = createProject(), [a, b] = clipsForTrack(project, 'lead');
  for (const clip of [a, b]) { clip.notes = [makeNote(0, 60, 4)]; clip.character.arp.enabled = false; }
  a.instrument.preset = 'A'; a.instrument.release = 1.5;
  b.instrument.preset = 'B'; b.instrument.release = .1;
  project.tracks.lead.solo = true;
  project.arrangement = [a, b].map(clip => ({ id: clip.id, name: clip.name, repeats: 1, clipIds: { ...project.activeClipIds, lead: clip.id } }));
  const engine = new AudioEngine(), voices = [];
  engine.project = project; engine.ctx = { currentTime: 0 }; engine.songMode = true;
  engine.sceneStep = 0; engine.position = 0; engine.updateEffectBus = () => {}; engine.scheduleAudioRegions = () => {};
  engine.voice = (...args) => voices.push(args[5]);
  engine.sceneIndex = 0; engine.scheduleMusicStep(.1);
  engine.sceneIndex = 1; engine.scheduleMusicStep(.2);
  engine.songMode = false; project.activeClipIds.lead = b.id; engine.scheduleMusicStep(.3);
  assert.deepEqual(voices.map(cfg => cfg.preset), ['A', 'B', 'B']);
  a.instrument.release = .01;
  assert.equal(voices[0].release, 1.5);
  assert.equal(voices[1].release, .1);
  assert.equal(voices[0].volume, project.tracks.lead.volume);
  const cutoff = createAutomationLane('track.lead.cutoff');
  cutoff.points = [{ id: 'cut', step: 0, value: .25, curve: 'linear' }];
  project.automationLanes.push(cutoff);
  const originalCutoff = b.instrument.cutoff;
  engine.scheduleMusicStep(.4);
  assert.equal(voices.at(-1).cutoff, 3090);
  assert.equal(b.instrument.cutoff, originalCutoff);
});


test('binary inventory includes takes and deduplicates shared region/sampler sources', () => {
  const p = createEmptyProject();
  p.sampler.assetId = 'shared'; p.sampler.name = 'Sampler'; p.sampler.type = 'audio/ogg';
  const lane = createAudioLane('Audio');
  lane.regions.push(createAudioRegion('shared', 'Region', 0, 16, 2)); p.audioLanes.push(lane);
  const take = createPerformanceTake('Live take', 16, []);
  take.audioAssetId = 'recording'; take.mimeType = 'audio/webm;codecs=opus'; p.performanceTakes.push(take);
  assert.deepEqual(projectAssets(p).map(({id,type}) => ({id,type})), [
    {id:'shared',type:'audio/ogg'}, {id:'recording',type:'audio/webm;codecs=opus'}
  ]);
  assert.deepEqual(projectAssets(migrateProject(JSON.parse(JSON.stringify(p)))) , projectAssets(p));
});

test('MIDI emits tempo ramps and later meter events at absolute musical ticks', () => {
  const p = createEmptyProject();
  p.tempoMap = [{id:'a',step:0,bpm:100,curve:'linear'}, {id:'b',step:8,bpm:160,curve:'jump'}];
  p.meterMap = [{id:'m',step:8,beats:3,unit:4}];
  const midi = encodeMidi(p), view = new DataView(midi.buffer);
  const end = 22 + view.getUint32(18); let offset = 22, tick = 0; const tempos = [], meters = [];
  while (offset < end) {
    let delta = 0, b;
    do { b=midi[offset++]; delta=(delta<<7)|(b&127); } while (b&128);
    tick += delta; assert.equal(midi[offset++],255);
    const type=midi[offset++], size=midi[offset++], data=[...midi.slice(offset,offset+size)]; offset+=size;
    if(type===81) tempos.push({tick,bpm:60000000/((data[0]<<16)|(data[1]<<8)|data[2])});
    if(type===88) meters.push({tick,beats:data[0],unit:2**data[1]});
  }
  assert.equal(tempos.length,33); assert.equal(tempos[0].tick,0); assert.equal(tempos.at(-1).tick,960);
  assert.ok(Math.abs(tempos.at(-1).bpm-160)<.001);
  assert.ok(meters.some(m=>m.tick===960&&m.beats===3&&m.unit===4));
});

test('shared clock integrates jumps, ramps, swing and region offsets', () => {
 const p=createEmptyProject(); p.swing=0;
 p.tempoMap=[{id:'a',step:0,bpm:120,curve:'jump'},{id:'b',step:8,bpm:60,curve:'jump'}];
 assert.equal(projectSeconds(p,16),3); assert.equal(projectDuration(p,8,8),2);
 p.tempoMap[0].curve='linear';
 assert.ok(Math.abs(projectSeconds(p,8)-2*Math.log(2))<1e-10);
 p.swing=.3;
 assert.ok(projectSeconds(p,1)>projectSeconds(p,1,false));
 assert.equal(projectDuration(p,0,2),projectSeconds(p,2,false));
});


test('global mixer rules cover audio solo, group mute and master automation without mutating the project',()=>{
 const p=createEmptyProject(),lane=createAudioLane('Voice');p.audioLanes.push(lane);lane.solo=true;
 assert.equal(mixAudible(p,'lead'),false);assert.equal(mixAudible(p,lane.id),true);
 lane.solo=false;const group=p.mixerGroups[0];p.tracks.lead.groupId=group.id;group.mute=true;
 assert.equal(mixAudible(p,'lead'),false);group.mute=false;group.volume=.5;
 const automation=createAutomationLane('master.volume');automation.points=[{id:'m',step:0,value:.2,curve:'jump'}];p.automationLanes.push(automation);
 assert.equal(masterValue(p,0),.2);
 const before=JSON.stringify(p),cfg=clipTrackState(p,activeClip(p,'lead'),0);
 assert.ok(Math.abs(cfg.volume-p.tracks.lead.volume*.5)<1e-10);assert.equal(JSON.stringify(p),before);
});

test('audio regions extend the song transport without repeating the last instrument scene',()=>{
 const p=createEmptyProject(),lane=createAudioLane('Long voice');lane.regions.push(createAudioRegion('voice','Long voice',8,40,6));p.audioLanes.push(lane);
 assert.equal(playbackEvents(p,{song:true}).durationSteps,48);
 const engine=new AudioEngine();engine.project=p;engine.songMode=true;assert.equal(engine.seek(40,true),40);
 assert.equal(engine.sceneIndex,p.arrangement.length);engine.advanceTransport();assert.equal(engine.position,41);
 engine.seek(47,true);engine.advanceTransport();assert.equal(engine.position,0);
});


test('WAV encoding reads channel views once and preserves stereo PCM samples', async()=>{
 let reads=0;const left=new Float32Array([-.5,.25,2]),right=new Float32Array([.5,-.25,-2]);
 const buffer={length:3,numberOfChannels:2,sampleRate:48000,getChannelData(channel){reads++;return channel?right:left}};
 const blob=wavBlob(buffer,32,false,false),view=new DataView(await blob.arrayBuffer());
 assert.equal(reads,2);assert.equal(blob.size,68);assert.equal(view.getFloat32(44,true),-.5);assert.equal(view.getFloat32(48,true),.5);assert.equal(view.getFloat32(60,true),1);assert.equal(view.getFloat32(64,true),-1);
});


test('render inventory requires audible composition sources without blocking on unrelated takes',()=>{
 const p=createEmptyProject(),take=createPerformanceTake('Unrelated take',16);take.audioAssetId='missing-take';p.performanceTakes.push(take);
 p.sampler.assetId='unused-sampler';assert.equal(renderAssets(p).length,0);
 const lane=createAudioLane('Voice');lane.regions.push(createAudioRegion('voice','Voice',8,8,1));p.audioLanes.push(lane);
 assert.deepEqual(renderAssets(p).map(asset=>asset.id),['voice']);assert.equal(renderAssets(p,false).length,0);assert.equal(renderAssets(p,true,{start:0,end:8}).length,0);
 lane.mute=true;assert.equal(renderAssets(p).length,0);
});


test('live audio-lane buses follow global Solo/Mute and group changes during a sustained region',()=>{
 const p=createEmptyProject(),lane=createAudioLane('Sustained voice');p.audioLanes.push(lane);const engine=new AudioEngine();engine.ctx={currentTime:0};
 const output={gain:{value:1,setTargetAtTime(value){this.value=value}},disconnect(){}};engine.audioLaneOutputs.set(lane.id,output);
 engine.setProject(p);assert.equal(output.gain.value,lane.volume);p.tracks.lead.solo=true;engine.setProject(p);assert.equal(output.gain.value,0);
 p.tracks.lead.solo=false;lane.mute=true;engine.setProject(p);assert.equal(output.gain.value,0);lane.mute=false;engine.setProject(p);assert.equal(output.gain.value,lane.volume);
 p.audioLanes=[];engine.setProject(p);assert.equal(engine.audioLaneOutputs.size,0);
});
